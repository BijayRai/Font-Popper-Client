/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
const expect = require('expect')
const colors = require('colors')

console.log('/********************************/'.grey)

describe('App', () => {
  it('Should pass', () => {
    expect(true).toBe(true)
  })
})
