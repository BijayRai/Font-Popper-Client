// @flow
import { connect } from 'react-redux'
import React from 'react'
import { bindActionCreators } from 'redux'
import Link from 'next/link'
import { renderSvg } from '../../utils/genericHelpers'
import { svgs } from '../../config/svgs'
import { logUserOut } from '../../actions/authActions'
import { toastr } from 'react-redux-toastr'
import Router from 'next/router'
import { unsetToken } from '../../utils/authUtils'
import type { User } from '../../flowTypes/User'

type Props = {
  logOut: Function,
  user: User
}
class isSignedIn extends React.Component<void, Props, void> {
  handleLogOut: Function

  constructor (props) {
    super(props)
    this.handleLogOut = this.handleLogOut.bind(this)
  }

  async handleLogOut () {
    try {
      await this.props.logOut()
      unsetToken()
      Router.push(`/auth/logout`, `/logout`)
      toastr.success('Logout', 'Successfully Logged Out')
    } catch (e) {}
  }

  render () {
    const {user} = this.props
    if (user.isAuthenticated) {
      return (
        <div className='nav__section nav__section--user'>
          <li className='nav__item'>
            <Link href='/auth/account' as='/account'>
              <img
                src={
                  user.gravatar
                    ? user.gravatar
                    : '/static/images/photos/default.jpg'
                }
                alt=''
                className='avatar'
              />
            </Link>
          </li>
          <li className='nav__item' onClick={this.handleLogOut}>
            <a className='nav__link'>
              {renderSvg(svgs.Logout)}
              Log Out
            </a>
          </li>
        </div>
      )
    } else {
      return (
        <div className='nav__section nav__section--user'>
          <li className='nav__item'>
            <Link href='/auth/register' as='/register'>
              <a className='nav__link'>Register</a>
            </Link>

          </li>
          <li className='nav__item'>
            <Link href='/auth/login' as='/login'>
              <a className='nav__link'>Log In</a>
            </Link>
          </li>
        </div>
      )
    }
  }
}
const mapStateToProps = (state) => {
  return {
    user: state.user
  }
}
const mapDispatchToProps = dispatch => {
  return {
    logOut: bindActionCreators(logUserOut, dispatch)
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(isSignedIn)
