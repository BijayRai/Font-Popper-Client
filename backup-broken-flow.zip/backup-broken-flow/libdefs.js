declare module 'react-redux' {
  declare var exports: any
}
declare module 'redux-form' {
  declare var exports: any
}
declare module 'redux' {
  declare var exports: any
}
declare module 'react-redux-toastr' {
  declare var exports: any
}
declare module 'moment' {
  declare var exports: any
}
declare module 'next-redux-wrapper' {
  declare var exports: any
}
declare module 'next/link' {
  declare var exports: any
}
declare module 'next/router' {
  declare var exports: any
}
declare module 'styled-components' {
  declare var exports: any
}
declare module 'jwt-decode' {
  declare var exports: any
}
declare module '../static/images/icons/logo.svg' {
  declare var exports: any
}
declare module '../static/images/icons/logo.svg' {
  declare var exports: any
}
declare module '../static/images/icons/logo.svg' {
  declare var exports: any
}
declare module '../static/images/icons/store.svg' {
  declare var exports: any
}
declare module '../static/images/icons/tag.svg' {
  declare var exports: any
}
declare module '../static/images/icons/top.svg' {
  declare var exports: any
}
declare module '../static/images/icons/add.svg' {
  declare var exports: any
}
declare module '../static/images/icons/map.svg' {
  declare var exports: any
}
declare module '../static/images/icons/pencil.svg' {
  declare var exports: any
}
declare module '../static/images/icons/logout.svg' {
  declare var exports: any
}
declare module '../static/images/icons/heart.svg' {
  declare var exports: any
}
declare module '../static/images/icons/review.svg' {
  declare var exports: any
}
declare module 'react-dropzone' {
  declare var exports: any
}
