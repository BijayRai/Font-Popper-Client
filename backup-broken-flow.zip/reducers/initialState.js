export default {
  time: 0,
  isSaving: false,
  user: {
    isAuthenticated: false
  },
  userAccount: {},
  filtered: {
    tags: [],
    stores: []
  }
}
