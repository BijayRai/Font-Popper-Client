
          window.__NEXT_REGISTER_PAGE('/_document', function() {
            var comp = module.exports =
webpackJsonp([1],{

/***/ 186:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  time: 0,
  isSaving: false,
  user: {
    isAuthenticated: false },

  userAccount: {},
  filtered: {
    tags: [],
    stores: [] } };

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/initialState.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/initialState.js"); } } })();

/***/ }),

/***/ 418:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.resetPassword = exports.forgotUser = exports.updateUser = exports.loadAccountForm = exports.refreshTokenAction = exports.authenticateUser = exports.saveUserToRedux = exports.logOut = exports.logUserOut = exports.signinUser = undefined;

var _regenerator = __webpack_require__(26);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(25);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

var _authApi = __webpack_require__(850);

var _authApi2 = _interopRequireDefault(_authApi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _this = undefined;var signinUser = exports.signinUser = function signinUser(user) {
  return function () {
    var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(dispatch) {
      var request;return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {case 0:
              request = _authApi2.default.signInUser(user);return _context.abrupt('return', dispatch({
                type: _actionTypes2.default.LOG_USER_IN,
                payload: request // request = Promise, must send data on key 'payload`
              }));case 2:case 'end':
              return _context.stop();}
        }
      }, _callee, _this);
    }));return function (_x) {
      return _ref.apply(this, arguments);
    };
  }();
};

var logUserOut = exports.logUserOut = function logUserOut() {
  return function () {
    var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2(dispatch) {
      var request;return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {case 0:
              request = _authApi2.default.signOutUser();return _context2.abrupt('return', dispatch({ type: _actionTypes2.default.LOG_OUT, payload: request }));case 2:case 'end':
              return _context2.stop();}
        }
      }, _callee2, _this);
    }));return function (_x2) {
      return _ref2.apply(this, arguments);
    };
  }();
};

var logOut = exports.logOut = function logOut() {
  return { type: _actionTypes2.default.LOG_OUT };
};

var saveUserToRedux = exports.saveUserToRedux = function saveUserToRedux(user) {
  return function (dispatch) {
    return dispatch({
      type: _actionTypes2.default.SAVE_USER,
      user: user });
  };
};

var authenticateUser = exports.authenticateUser = function authenticateUser(user) {
  return function () {
    var _ref3 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3(dispatch) {
      var response;return _regenerator2.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {case 0:
              response = _authApi2.default.registerUser(user);return _context3.abrupt('return', dispatch({
                type: _actionTypes2.default.CREATE_USER,
                payload: response // request = Promise, must send data on key 'payload`
              }));case 2:case 'end':
              return _context3.stop();}
        }
      }, _callee3, _this);
    }));return function (_x3) {
      return _ref3.apply(this, arguments);
    };
  }();
};

var refreshTokenAction = exports.refreshTokenAction = function refreshTokenAction(user) {
  return function (dispatch) {
    var request = _authApi2.default.fetchRefreshTokens(user);

    return dispatch({
      type: _actionTypes2.default.FETCH_NEW_TOKENS,
      payload: request });
  };
};

var loadAccountForm = exports.loadAccountForm = function loadAccountForm(user) {
  return {
    type: _actionTypes2.default.LOAD_USER_DATA,
    user: user };
};

var updateUser = exports.updateUser = function updateUser(user) {
  return function (dispatch) {
    var request = _authApi2.default.updateUser(user);

    return dispatch({
      type: _actionTypes2.default.UPDATE_USER,
      payload: request // request = Promise, must send data on key 'payload`
    });
  };
};

var forgotUser = exports.forgotUser = function forgotUser(email) {
  return function (dispatch) {
    var request = _authApi2.default.forgotUser(email);

    return dispatch({
      type: _actionTypes2.default.FORGOT_USER,
      payload: request // request = Promise, must send data on key 'payload`
    });
  };
};

var resetPassword = exports.resetPassword = function resetPassword(passwordToken) {
  return function (dispatch) {
    var request = _authApi2.default.resetPassword(passwordToken);

    return dispatch({
      type: _actionTypes2.default.RESET_PASSWORD,
      payload: request // request = Promise, must send data on key 'payload`
    });
  };
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/actions/authActions.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/actions/authActions.js"); } } })();

/***/ }),

/***/ 419:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
                                       value: true
});
var prod = "development" === 'production';
var config = __webpack_require__(550);

/*
                                       https://testone.now.sh/api = myapi.nw.sh/api
                                       because of this translation - the routes on the API need to be looking for /api/__route__
                                       Since Now does it this way - in order to have our app ready for Prod deployment, adding api on the end of
                                       localHost:3000/api -> translates to http://localhost:7777 due to http-proxy - so now our original /api/__route__
                                       will still work in both Dev and Production
                                       */
exports.default = {
                                       BACKEND_URL: prod ? config.PROD_URL : config.DEV_URL,
                                       WEBSITE_TITLE: 'Now Thats Delicious!',
                                       REFRESH_WINDOW: config.REFRESH_WINDOW,
                                       TAGS: ['Wifi', 'Open Late', 'Family Friendly', 'Vegetarian', 'Licensed'] };

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/config/envConfig.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/config/envConfig.js"); } } })();

/***/ }),

/***/ 453:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__resourceQuery) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getPrototypeOf = __webpack_require__(52);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(55);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(54);

var _inherits3 = _interopRequireDefault(_inherits2);

var _react = __webpack_require__(3);

var _react2 = _interopRequireDefault(_react);

var _document = __webpack_require__(759);

var _document2 = _interopRequireDefault(_document);

var _nextReduxWrapper = __webpack_require__(750);

var _nextReduxWrapper2 = _interopRequireDefault(_nextReduxWrapper);

var _store = __webpack_require__(856);

var _styledComponents = __webpack_require__(983);

var _envConfig = __webpack_require__(419);

var _envConfig2 = _interopRequireDefault(_envConfig);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var MyDocument = function (_Document) {
  (0, _inherits3.default)(MyDocument, _Document);function MyDocument() {
    (0, _classCallCheck3.default)(this, MyDocument);return (0, _possibleConstructorReturn3.default)(this, (MyDocument.__proto__ || (0, _getPrototypeOf2.default)(MyDocument)).apply(this, arguments));
  }(0, _createClass3.default)(MyDocument, [{ key: 'render', value: function render() {
      var sheet = new _styledComponents.ServerStyleSheet();
      var main = sheet.collectStyles(_react2.default.createElement(_document.Main, null));
      var styleTags = sheet.getStyleElement();

      return _react2.default.createElement('html', null, _react2.default.createElement(_document.Head, null, _react2.default.createElement('link', {
        rel: 'shortcut icon',
        type: 'image/png',
        href: '/static/images/icons/doughnut.png' }), _react2.default.createElement('link', { href: '/static/toastr.css', rel: 'stylesheet', type: 'text/css' }), _react2.default.createElement('link', {
        async: true,
        href: '//fonts.googleapis.com/css?family=Open+Sans',
        rel: 'stylesheet',
        type: 'text/css' }), _react2.default.createElement('title', null, _envConfig2.default.WEBSITE_TITLE), styleTags, _react2.default.createElement('link', { rel: 'stylesheet', type: 'text/css', href: '/static/styles.css' })), _react2.default.createElement('body', null, main, _react2.default.createElement(_document.NextScript, null)));
    } }]);return MyDocument;
}(_document2.default);

exports.default = (0, _nextReduxWrapper2.default)(_store.initStore)(MyDocument);

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/pages/_document.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/pages/_document.js"); } } })();
    (function (Component, route) {
      if (false) return
      if (false) return

      var qs = __webpack_require__(114)
      var params = qs.parse(__resourceQuery.slice(1))
      if (params.entry == null) return

      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(module.exports.default || module.exports, "/_document")
  
/* WEBPACK VAR INJECTION */}.call(exports, "?entry"))

/***/ }),

/***/ 550:
/***/ (function(module, exports) {

module.exports = {
	"DEV_URL": "http://localhost:3000/api",
	"PROD_URL": "https://testone.now.sh",
	"REFRESH_WINDOW": 15
};

/***/ }),

/***/ 63:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var actionTypes = {
  // Moment
  TICK: 'TICK',

  // AUTH
  REFRESH_TOKEN: 'REFRESH_TOKEN',
  FETCH_NEW_TOKENS: 'FETCH_NEW_TOKENS',
  CREATE_USER: 'CREATE_USER',
  SAVE_USER: 'SAVE_USER',
  LOG_OUT: 'LOG_OUT',
  LOG_USER_IN: 'LOG_USER_IN',
  FORGOT_USER: 'FORGOT_USER',
  RESET_PASSWORD: 'RESET_PASSWORD',

  // User Account
  LOAD_USER_DATA: 'LOAD_USER_DATA',
  UPDATE_USER: 'UPDATE_USER',

  // PAGINATION
  REQUEST_PAGE: 'REQUEST_PAGE',
  RECEIVE_PAGE: 'RECEIVE_PAGE' };

exports.default = actionTypes;

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/actions/actionTypes.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/actions/actionTypes.js"); } } })();

/***/ }),

/***/ 849:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createPaginator = undefined;

var _getIterator2 = __webpack_require__(122);

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _defineProperty2 = __webpack_require__(198);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _extends2 = __webpack_require__(40);

var _extends3 = _interopRequireDefault(_extends2);

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

var _redux = __webpack_require__(67);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var createPaginator = exports.createPaginator = function createPaginator(endpoint, resultKey) {
  // action
  var requestPage = function requestPage(endpoint, resultKey, page) {
    return {
      type: _actionTypes2.default.REQUEST_PAGE,
      payload: {
        page: page },

      meta: {
        endpoint: endpoint,
        resultKey: resultKey } };
  };

  // action
  var receivePage = function receivePage(resultKey, page, results) {
    return {
      type: _actionTypes2.default.RECEIVE_PAGE,
      payload: {
        page: page,
        results: results },

      meta: {
        resultKey: resultKey } };
  };
  // Reducer
  var pages = function pages() {
    var pages = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    switch (action.type) {
      case _actionTypes2.default.REQUEST_PAGE:
        return (0, _extends3.default)({}, pages, (0, _defineProperty3.default)({}, action.meta.resultKey, (0, _defineProperty3.default)({}, action.payload.page, {
          ids: [],
          fetching: true })));

      case _actionTypes2.default.RECEIVE_PAGE:
        return (0, _extends3.default)({}, pages, (0, _defineProperty3.default)({}, resultKey, (0, _defineProperty3.default)({}, action.payload.page, {
          ids: action.payload.results.map(function (store) {
            return store._id;
          }),
          fetching: false })));

      default:
        return pages;}
  };

  // Reducer
  var currentPage = function currentPage() {
    var currentPage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};return action.type === _actionTypes2.default.REQUEST_PAGE ? action.payload.page : currentPage;
  };

  var onlyForEndpoint = function onlyForEndpoint(reducer) {
    return function () {
      var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      if (typeof action.meta === 'undefined') {
        return state;
      }
      if (action.meta.endpoint === endpoint) {
        return reducer(state, action);
      }

      if (action.meta.resultKey === resultKey) {
        return reducer(state, action);
      }

      return state;

      // (typeof action.meta === 'undefined'
      //   ? state
      //   : action.meta.endpoint === endpoint ? reducer(state, action) : state)
    };
  };

  var itemsReducer = function itemsReducer() {
    var items = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    switch (action.type) {
      case _actionTypes2.default.RECEIVE_PAGE:
        var _items = {};var _iteratorNormalCompletion = true;var _didIteratorError = false;var _iteratorError = undefined;try {
          for (var _iterator = (0, _getIterator3.default)(action.payload.results), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var item = _step.value;
            _items = (0, _extends3.default)({}, _items, (0, _defineProperty3.default)({}, item._id, item));
          }
        } catch (err) {
          _didIteratorError = true;_iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
        return (0, _extends3.default)({}, items, _items);

      default:
        return items;}
  };

  var reducer = onlyForEndpoint((0, _redux.combineReducers)({
    pages: pages,
    currentPage: currentPage }));

  return {
    requestPage: requestPage,
    receivePage: receivePage,
    reducer: reducer,
    itemsReducer: onlyForEndpoint(itemsReducer) };
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/actions/paginator.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/actions/paginator.js"); } } })();

/***/ }),

/***/ 850:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _regenerator = __webpack_require__(26);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _stringify = __webpack_require__(457);

var _stringify2 = _interopRequireDefault(_stringify);

var _asyncToGenerator2 = __webpack_require__(25);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = __webpack_require__(15);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(16);

var _createClass3 = _interopRequireDefault(_createClass2);

var _isomorphicUnfetch = __webpack_require__(549);

var _isomorphicUnfetch2 = _interopRequireDefault(_isomorphicUnfetch);

var _envConfig = __webpack_require__(419);

var _envConfig2 = _interopRequireDefault(_envConfig);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var authApi = function () {
  function authApi() {
    (0, _classCallCheck3.default)(this, authApi);
  }(0, _createClass3.default)(authApi, null, [{ key: 'signInUser', value: function () {
      var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(user) {
        var url;return _regenerator2.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {case 0:
                url = _envConfig2.default.BACKEND_URL + '/api/signin';return _context.abrupt('return', (0, _isomorphicUnfetch2.default)(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json' },

                  // mode: 'cors',
                  credentials: 'include', // Don't forget to specify this if you need cookies
                  body: (0, _stringify2.default)(user) }));case 2:case 'end':
                return _context.stop();}
          }
        }, _callee, this);
      }));function signInUser(_x) {
        return _ref.apply(this, arguments);
      }return signInUser;
    }() }, { key: 'signOutUser', value: function () {
      var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
        var url;return _regenerator2.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {case 0:

                url = _envConfig2.default.BACKEND_URL + '/api/signout';return _context2.abrupt('return', (0, _isomorphicUnfetch2.default)(url, {
                  method: 'GET',
                  headers: {
                    'Content-Type': 'application/json' },

                  credentials: 'include' }));case 2:case 'end':
                return _context2.stop();}
          }
        }, _callee2, this);
      }));function signOutUser() {
        return _ref2.apply(this, arguments);
      }return signOutUser;
    }() }, { key: 'registerUser', value: function () {
      var _ref3 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3(user) {
        var url, response;return _regenerator2.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {case 0:
                url = _envConfig2.default.BACKEND_URL + '/api/register';_context3.next = 3;return (0, _isomorphicUnfetch2.default)(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json' },

                  credentials: 'include', // Don't forget to specify this if you need cookies
                  body: (0, _stringify2.default)(user) });case 3:
                response = _context3.sent;return _context3.abrupt('return', response);case 5:case 'end':
                return _context3.stop();}
          }
        }, _callee3, this);
      }));function registerUser(_x2) {
        return _ref3.apply(this, arguments);
      }return registerUser;
    }() }, { key: 'fetchRefreshTokens', value: function () {
      var _ref4 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee4() {
        var url, response;return _regenerator2.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {case 0:

                url = _envConfig2.default.BACKEND_URL + '/api/refresh';_context4.next = 3;return (0, _isomorphicUnfetch2.default)(url, {
                  method: 'GET',
                  credentials: 'include' });case 3:
                response = _context4.sent;return _context4.abrupt('return', response);case 5:case 'end':
                return _context4.stop();}
          }
        }, _callee4, this);
      }));function fetchRefreshTokens() {
        return _ref4.apply(this, arguments);
      }return fetchRefreshTokens;
    }() }, { key: 'updateUser', value: function () {
      var _ref5 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee5(user) {
        var url, response;return _regenerator2.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {case 0:
                url = _envConfig2.default.BACKEND_URL + '/api/account';_context5.next = 3;return (0, _isomorphicUnfetch2.default)(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json' },

                  credentials: 'include',
                  body: (0, _stringify2.default)(user) });case 3:
                response = _context5.sent;return _context5.abrupt('return', response);case 5:case 'end':
                return _context5.stop();}
          }
        }, _callee5, this);
      }));function updateUser(_x3) {
        return _ref5.apply(this, arguments);
      }return updateUser;
    }() }, { key: 'forgotUser', value: function () {
      var _ref6 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee6(email) {
        var url, response;return _regenerator2.default.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {case 0:
                url = _envConfig2.default.BACKEND_URL + '/api/account/forgot';_context6.next = 3;return (0, _isomorphicUnfetch2.default)(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json' },

                  credentials: 'include',
                  body: (0, _stringify2.default)(email) });case 3:
                response = _context6.sent;return _context6.abrupt('return', response);case 5:case 'end':
                return _context6.stop();}
          }
        }, _callee6, this);
      }));function forgotUser(_x4) {
        return _ref6.apply(this, arguments);
      }return forgotUser;
    }() }, { key: 'resetPassword', value: function () {
      var _ref7 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee7(passwordToken) {
        var url, response;return _regenerator2.default.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {case 0:
                url = _envConfig2.default.BACKEND_URL + '/api/account/reset';_context7.next = 3;return (0, _isomorphicUnfetch2.default)(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json' },

                  credentials: 'include',
                  body: (0, _stringify2.default)(passwordToken) });case 3:
                response = _context7.sent;return _context7.abrupt('return', response);case 5:case 'end':
                return _context7.stop();}
          }
        }, _callee7, this);
      }));function resetPassword(_x5) {
        return _ref7.apply(this, arguments);
      }return resetPassword;
    }() }]);return authApi;
}();

exports.default = authApi;

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/api/authApi.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/api/authApi.js"); } } })();

/***/ }),

/***/ 851:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (_ref) {
  var _this = this;var dispatch = _ref.dispatch;
  return function (next) {
    return function () {
      var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(action) {
        var response, body, _newAction, _newAction2, decodedUser, newAction;return _regenerator2.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {case 0:
                if (!(!action.payload || !action.payload.then)) {
                  _context.next = 2;break;
                }return _context.abrupt('return', next(action));case 2:
                _context.prev = 2;_context.next = 5;return action.payload;case 5:
                response = _context.sent;_context.next = 8;return (0, _errorHandlers.handleStatusCheck)(response, dispatch, action.type);case 8:
                _context.next = 10;return response.json();case 10:
                body = _context.sent;if (!(body.token && action.type === 'LOG_USER_IN')) {
                  _context.next = 15;break;
                }
                // Currently this action has no reducer
                _newAction = {
                  type: action.type,
                  data: {
                    token: body.token,
                    hearts: body.hearts

                    // Send through all the middlewares again
                  } };dispatch(_newAction);

                // MODIFY CREATE TO DO THE SAME THING WITH HEARTS
                return _context.abrupt('return', {
                  token: body.token,
                  hearts: body.hearts });case 15:
                if (!(body.token && action.type === 'CREATE_USER')) {
                  _context.next = 19;break;
                }
                _newAction2 = {
                  type: action.type,
                  data: body.token

                  // Send through all the middlewares again
                };dispatch(_newAction2);return _context.abrupt('return', body.token);case 19:

                if (body.token && action.type !== 'LOG_OUT') {
                  console.log('body has token in it');
                  console.log('save new user to redux');

                  decodedUser = (0, _authUtils.getUserFromJWT)(body.token);

                  dispatch({
                    type: _actionTypes2.default.REFRESH_TOKEN,
                    user: (0, _extends3.default)({}, decodedUser) });
                }

                newAction = {
                  type: action.type,
                  data: body.data

                  // console.log('new action')
                  // console.log(newAction)

                  // Send through all the middlewares again
                };dispatch(newAction);return _context.abrupt('return', body.data);case 25:
                _context.prev = 25;_context.t0 = _context['catch'](2);

                console.log('middleware error');
                (0, _errorHandlers.handleMiddlewareError)(_context.t0, dispatch);throw _context.t0;case 30:case 'end':
                return _context.stop();}
          }
        }, _callee, _this, [[2, 25]]);
      }));return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }();
  };
};

var _regenerator = __webpack_require__(26);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends2 = __webpack_require__(40);

var _extends3 = _interopRequireDefault(_extends2);

var _asyncToGenerator2 = __webpack_require__(25);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _authUtils = __webpack_require__(857);

var _errorHandlers = __webpack_require__(858);

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/middleware/apiIntercepter.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/middleware/apiIntercepter.js"); } } })();

/***/ }),

/***/ 852:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.authReducer = undefined;

var _extends2 = __webpack_require__(40);

var _extends3 = _interopRequireDefault(_extends2);

var _assign = __webpack_require__(51);

var _assign2 = _interopRequireDefault(_assign);

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

var _initialState = __webpack_require__(186);

var _initialState2 = _interopRequireDefault(_initialState);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var authReducer = exports.authReducer = function authReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _initialState2.default.user;var action = arguments[1];
  switch (action.type) {
    // case actionTypes.TOGGLE_LOGIN:
    //   return Object.assign({}, state, {
    //     isAuthenticated: !state.isAuthenticated
    //   })
    case _actionTypes2.default.SAVE_USER:
      return (0, _assign2.default)({}, state, (0, _extends3.default)({}, action.user, {
        isAuthenticated: true }));

    case _actionTypes2.default.REFRESH_TOKEN:
      return (0, _assign2.default)({}, state, (0, _extends3.default)({}, action.user, {
        isAuthenticated: true }));

    case _actionTypes2.default.LOG_OUT:
      return {
        isAuthenticated: false };

    default:
      return state;}
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/authReducer.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/authReducer.js"); } } })();

/***/ }),

/***/ 853:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.editAccountReducer = undefined;

var _assign = __webpack_require__(51);

var _assign2 = _interopRequireDefault(_assign);

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

var _initialState = __webpack_require__(186);

var _initialState2 = _interopRequireDefault(_initialState);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var editAccountReducer = exports.editAccountReducer = function editAccountReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _initialState2.default.userAccount;var action = arguments[1];
  switch (action.type) {
    case _actionTypes2.default.LOAD_USER_DATA:
      return (0, _assign2.default)({}, state, {
        data: action.user });

    default:
      return state;}
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/editAccountReducer.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/editAccountReducer.js"); } } })();

/***/ }),

/***/ 854:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.pagination = undefined;

var _actionTypes = __webpack_require__(63);

var _actionTypes2 = _interopRequireDefault(_actionTypes);

var _paginator = __webpack_require__(849);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Data shape - RECIEVE STORE PAGE
// pagination: {
//     pages: {
//       1: {
//         ids: [ 'todo1', 'todo2' ],
//         fetching: false
//       },
//     }
// }

var pagination = exports.pagination = (0, _paginator.createPaginator)('/stores', 'stores');
// import initialState from './initialState'

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/pageReducer.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/pageReducer.js"); } } })();

/***/ }),

/***/ 855:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.timeReducer = undefined;

var _assign = __webpack_require__(51);

var _assign2 = _interopRequireDefault(_assign);

var _initialState = __webpack_require__(186);

var _initialState2 = _interopRequireDefault(_initialState);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var timeReducer = exports.timeReducer = function timeReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _initialState2.default.time;var action = arguments[1];
  switch (action.type) {
    case 'TICK':
      return (0, _assign2.default)({}, state, action.tokenTime);
    default:
      return state;}
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/timeReducer.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/reducers/timeReducer.js"); } } })();

/***/ }),

/***/ 856:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initStore = undefined;

var _redux = __webpack_require__(67);

var _reduxThunk = __webpack_require__(975);

var _reduxThunk2 = _interopRequireDefault(_reduxThunk);

var _reduxDevtoolsExtension = __webpack_require__(904);

var _reduxForm = __webpack_require__(941);

var _authReducer = __webpack_require__(852);

var _timeReducer = __webpack_require__(855);

var _reactReduxToastr = __webpack_require__(422);

var _editAccountReducer = __webpack_require__(853);

var _apiIntercepter = __webpack_require__(851);

var _apiIntercepter2 = _interopRequireDefault(_apiIntercepter);

var _pageReducer = __webpack_require__(854);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var initStore = exports.initStore = function initStore() {
  var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  // mirror of state from original app
  var reducers = (0, _redux.combineReducers)({
    user: _authReducer.authReducer,
    form: _reduxForm.reducer,
    userAccount: _editAccountReducer.editAccountReducer,
    toastr: _reactReduxToastr.reducer,
    time: _timeReducer.timeReducer,
    pagination: _pageReducer.pagination.reducer });

  var env = "development" || 'development';

  if (typeof window !== 'undefined' && env === 'development') {
    return (0, _redux.createStore)(reducers, initialState, (0, _reduxDevtoolsExtension.composeWithDevTools)((0, _redux.applyMiddleware)(_reduxThunk2.default, _apiIntercepter2.default)));
  }

  return (0, _redux.createStore)(reducers, initialState, (0, _redux.applyMiddleware)(_reduxThunk2.default, _apiIntercepter2.default));
};

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/store.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/store.js"); } } })();

/***/ }),

/***/ 857:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validateUserTokenServer = exports.validateUserTokenClient = exports.isUserExpired = exports.getUserFromJWT = exports.findCookies = exports.convertResCookiesToString = exports.findTokenToDecode = exports.getCookiesFromServerResponse = exports.getTokenFromCookieRes = exports.getTokenFromCookie = exports.unsetToken = undefined;

var _regenerator = __webpack_require__(26);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(25);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _defineProperty2 = __webpack_require__(198);

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _extends2 = __webpack_require__(40);

var _extends3 = _interopRequireDefault(_extends2);

var _keys = __webpack_require__(197);

var _keys2 = _interopRequireDefault(_keys);

var _jwtDecode = __webpack_require__(553);

var _jwtDecode2 = _interopRequireDefault(_jwtDecode);

var _moment = __webpack_require__(0);

var _moment2 = _interopRequireDefault(_moment);

var _authActions = __webpack_require__(418);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _this = undefined;

/**
                                                  * unsetToken()
                                                  * - Adds logout timestamp to localstorage to trigger event accross tabs
                                                  *
                                                  */
var unsetToken = exports.unsetToken = function unsetToken() {
  if (!process.browser) {
    return;
  }
  // window.localStorage.removeItem('token')
  // window.localStorage.removeItem('user')
  // Cookie.remove('jwt')

  window.localStorage.setItem('logout', Date.now());
};
var stringSplit = function stringSplit(jwtToken, splitter) {
  if (!jwtToken) return undefined;
  return jwtToken.split(splitter)[1];
};

var findKey = function findKey(jwtToken, key) {
  if (!jwtToken) return undefined;
  return jwtToken.split(';').find(function (c) {
    return c.trim().startsWith(key + '=');
  });
};

/**
    * getTokenFromCookie(arg)
    *
    * @param {Object} request - from Server-side
    * @returns {Object} undefined
    * @returns {string} jwt-token
    */
var getTokenFromCookie = exports.getTokenFromCookie = function getTokenFromCookie(request) {
  if (!request.headers.cookie) {
    return undefined;
  }

  var jwtCookie = request.headers.cookie;
  return stringSplit(findKey(jwtCookie, 'jwt'), '=');
};

/**
    * getTokenFromCookieRes(arg) - used specifically for RESPONSE cookies on SSR next.js
    *
    * @param {Array} cookies - from Server-side
    * @returns {string} jwt-token || undefined
    */
var getTokenFromCookieRes = exports.getTokenFromCookieRes = function getTokenFromCookieRes(cookies) {
  console.log('find error');
  console.log(cookies);

  if (!cookies) {
    return undefined;
  }
  console.log('step1');

  console.log(cookies[0]);
  console.log('step2');

  return stringSplit(findKey(cookies[0], 'jwt'), '=');
};

/**
    * getCookiesFromServerResponse(arg)
    * - Helper hack to get cookies from headers on Next.js Server response
    *
    * @param {Object} ctxHeaders - from Server-side
    * @returns {String} cookies
    */
var getCookiesFromServerResponse = exports.getCookiesFromServerResponse = function getCookiesFromServerResponse(ctxHeaders) {
  if (!ctxHeaders) return undefined;

  var resCookies = ctxHeaders['set-cookie'];
  return resCookies;
};

/**
    * findTokenToDecode(headers, req)
    * - Next.js Server-side func to first look for new token being sent from API
    * - If none is found on RES, use req headers
    *
    * @param {Object} ctxHeaders - from Server-side
    * @param {Object} ctxReq - from Server-side
    * @returns {String} Cookie Token
    */
var findTokenToDecode = exports.findTokenToDecode = function findTokenToDecode(ctxHeaders, ctxReq) {
  var cookies = getCookiesFromServerResponse(ctxHeaders);

  if (cookies) {
    console.log('has new user');
    return getTokenFromCookieRes(cookies);
  } else {
    console.log('no new user, use original token if there is one');
    return getTokenFromCookie(ctxReq);
  }
};

/**
    * convertResCookiesToString(cookies)
    * - Next.js Server-side func to convert Cookie from Response API
    *
    * @param {Array} cookies - from Server-side
    * @returns {String} Cookie Token
    */
var convertResCookiesToString = exports.convertResCookiesToString = function convertResCookiesToString(cookies) {
  var cookiesArray = [];

  var jwtString = stringSplit(findKey(cookies[0], 'jwt'), '=');
  var jwt = 'jwt=' + String(jwtString);

  var csrfString = stringSplit(findKey(cookies[1], '_CSRF'), '=');
  var csrf = '_CSRF=' + String(csrfString);

  cookiesArray.push(jwt, csrf);
  return cookiesArray.toString().replace(',', '; ');
};

/**
    * findCookies(ctxHeaders, ctxReq)
    * - Next.js Server-side func to first look for new token being sent from API
    * - This helps the Validate Server Token function looking for cookies server-side
    *
    * @param {Object} ctxHeaders - from Server-side
    * @param {Object} ctxReq - from Server-side
    * @returns {String} JWT - Token
    */
var findCookies = exports.findCookies = function findCookies(ctxHeaders, ctxReq) {
  if (!ctxReq) {
    return undefined;
  }

  if (!ctxHeaders) {
    return ctxReq.headers.cookie;
  }

  var cookies = getCookiesFromServerResponse(ctxHeaders);

  if (cookies) {
    console.log('has new cookies');
    return convertResCookiesToString(cookies);
  } else {
    console.log('use old cookies');
    return ctxReq.headers.cookie;
  }
};

/**
    * getUserFromJWT(arg)
    * - Filter out sensitive info when the token is decoded before adding to redux
    *
    * @param {String} token
    * @returns {Object}
    *
    */
var getUserFromJWT = exports.getUserFromJWT = function getUserFromJWT(token) {
  if (!token) {
    return undefined;
  }

  var tokenDecoded = (0, _jwtDecode2.default)(token);
  // Would want to allow metaData here
  var allowedKeys = ['name', 'email', 'exp', 'sub'];

  return (0, _keys2.default)(tokenDecoded).filter(function (key) {
    return allowedKeys.includes(key);
  }).reduce(function (obj, key) {
    return (0, _extends3.default)({}, obj, (0, _defineProperty3.default)({}, key, tokenDecoded[key]));
  }, {});

  // return jwtDecode(token)
};

/**
    * isUserExpired(user)
    *
    * @param {Object} user
    * @returns {Boolean}
    *
    */
var isUserExpired = exports.isUserExpired = function isUserExpired(user) {
  if (user.exp) {
    var currentTime = (0, _moment2.default)().unix();
    var expired = user.exp < currentTime; // because time goes up

    if (expired) {
      return true;
    }
  }

  return false;
};

/**
    * validateUserTokenClient(store, user)
    *
    * @param {Object} store
    * @param {Object} user
    * @returns {Object} {Dispatch Action: logOut}
    * @returns {Object} {Dispatch Action: logUserOut}
    * @returns {Object} {Dispatch Action: refreshToken}
    * @returns {Object} {Dispatch Action: saveUserToRedux}
    */
var validateUserTokenClient = exports.validateUserTokenClient = function () {
  var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(store, user) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {case 0:
            console.log('validateUser-Client');if (user) {
              _context.next = 3;break;
            }return _context.abrupt('return', store.dispatch((0, _authActions.logUserOut)()));case 3:
            if (!isUserExpired(user)) {
              _context.next = 14;break;
            }
            console.log('user is expired');_context.prev = 5;_context.next = 8;return store.dispatch((0, _authActions.refreshTokenAction)(user));case 8:
            return _context.abrupt('return', _context.sent);case 11:
            _context.prev = 11;_context.t0 = _context['catch'](5);

            console.log('refresh token error');case 14:case 'end':
            return _context.stop();}
      }
    }, _callee, _this, [[5, 11]]);
  }));return function validateUserTokenClient(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
                                                                                                                                                                                                                          * validateUserTokenServer(store, user, cookie)
                                                                                                                                                                                                                          *
                                                                                                                                                                                                                          * @param {Object} store
                                                                                                                                                                                                                          * @param {Object} user
                                                                                                                                                                                                                          * @param {Object} cookies
                                                                                                                                                                                                                          * @returns {Object} {Dispatch Action: logOut}
                                                                                                                                                                                                                          * @returns {Object} {Dispatch Action: logUserOut} (expired)
                                                                                                                                                                                                                          * @returns {Object} {Dispatch Action: saveUserToRedux}
                                                                                                                                                                                                                          */
var validateUserTokenServer = exports.validateUserTokenServer = function () {
  var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2(store, user, cookies) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {case 0:
            /*
                                                                                                                                                                                                                                                                               * find cookies on browser(jwt)
                                                                                                                                                                                                                                                                               * find user from token and pass user in to this function from getInitialProps on HOC
                                                                                                                                                                                                                                                                               * - if there is no user(undefined) - dispatch logout
                                                                                                                                                                                                                                                                               * - if there is a new user
                                                                                                                                                                                                                                                                               * - return new user to save to redux
                                                                                                                                                                                                                                                                               * - return old user to save to redux
                                                                                                                                                                                                                                                                               */
            console.log('validateUser-Server', user);if (user) {
              _context2.next = 3;break;
            }return _context2.abrupt('return', store.dispatch((0, _authActions.logOut)()));case 3:

            /*
                                               Save user from token
                                               */
            console.log('save user');

            // example of getting more USER meta data
            // Than what is just given to us from the JWT
            // await store.dispatch(getUserHearts(cookies))
            return _context2.abrupt('return', store.dispatch((0, _authActions.saveUserToRedux)(user)));case 5:case 'end':
            return _context2.stop();}
      }
    }, _callee2, _this);
  }));return function validateUserTokenServer(_x3, _x4, _x5) {
    return _ref2.apply(this, arguments);
  };
}();

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/utils/authUtils.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/utils/authUtils.js"); } } })();
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(47)))

/***/ }),

/***/ 858:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.handleStatusCheck = exports.handleMiddlewareError = undefined;

var _regenerator = __webpack_require__(26);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(25);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _reactReduxToastr = __webpack_require__(422);

var _index = __webpack_require__(79);

var _index2 = _interopRequireDefault(_index);

var _authActions = __webpack_require__(418);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _this = undefined;
/**
                                                      * handleMiddlewareError(arg) -DEPRICATED-
                                                      * - This function SHOULD BE updated once old async calls are routed through the middleware
                                                      * - No logout errror OBJ will be sent out so update accordingly
                                                      * - Currently this is in storeAPI.js
                                                      *
                                                      * @param {Object} error
                                                      * @param {Object} redux dispatch
                                                      */
var handleMiddlewareError = exports.handleMiddlewareError = function () {
  var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(e, dispatch) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {case 0:
            console.log('handleError from AuthUtils to be UPDATED and FIXED');
            console.log(e);

            if (e.logout) {
              _reactReduxToastr.toastr.error('Error:', e.message);
              // dispatch(logUserOut())
              console.log('SHOULD LOG USER OUR, BUT SHOULD HAPPEN WITH MIDDLEWARE NOT ERROR HANDLER');

              _index2.default.push('/auth/login', '/login');
            }

            if (e.showMid) {
              _reactReduxToastr.toastr.error('Error:', e.message);
            }case 4:case 'end':
            return _context.stop();}
      }
    }, _callee, _this);
  }));return function handleMiddlewareError(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
                                                                                                                                                                          * handleStatusCheck(res, dispatch)
                                                                                                                                                                          * - Redux Middleware apiIntercepter status check
                                                                                                                                                                          * - Used to upload files/photos
                                                                                                                                                                          *
                                                                                                                                                                          * @param {Object} api response
                                                                                                                                                                          * @param {Function} dispatch
                                                                                                                                                                          * @returns Action dispatch( logUserOut )
                                                                                                                                                                          * @returns {Error}
                                                                                                                                                                          */
var handleStatusCheck = exports.handleStatusCheck = function () {
  var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2(response, dispatch, actionType) {
    var error, newError;return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {case 0:
            console.log('handle Status Check');
            console.log(response.status);

            error = {
              showMid: false, // show middleware error instead of handling error in a component
              message: 'There was an error'

              // Specail message for login action error
            };if (!(response.status === 401 && actionType === 'LOG_USER_IN')) {
              _context2.next = 6;break;
            }
            error.message = 'Incorrect Username or password';throw error;case 6:
            if (!(response.status === 401)) {
              _context2.next = 12;break;
            }
            error.showMid = true;
            error.message = 'Please login again';_context2.next = 11;return dispatch((0, _authActions.logUserOut)());case 11:
            throw error;case 12:
            if (!(response.status === 422)) {
              _context2.next = 21;break;
            }_context2.next = 15;return response.json();case 15:
            newError = _context2.sent;if (!Array.isArray(newError.errors)) {
              _context2.next = 20;break;
            }throw newError.errors;case 20:
            throw newError.error;case 21:
            if (!(response.status !== 200)) {
              _context2.next = 24;break;
            }
            error.message = response.statusText;throw error;case 24:case 'end':
            return _context2.stop();}
      }
    }, _callee2, _this);
  }));return function handleStatusCheck(_x3, _x4, _x5) {
    return _ref2.apply(this, arguments);
  };
}();

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } if (typeof module.exports === 'function') { __REACT_HOT_LOADER__.register(module.exports, 'module.exports', "/Users/EveryTuesday/Documents/github/font-popper/client/utils/errorHandlers.js"); return; } for (var key in module.exports) { if (!Object.prototype.hasOwnProperty.call(module.exports, key)) { continue; } var namedExport = void 0; try { namedExport = module.exports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "/Users/EveryTuesday/Documents/github/font-popper/client/utils/errorHandlers.js"); } } })();

/***/ }),

/***/ 997:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(453);


/***/ })

},[997]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZWR1Y2Vycy9pbml0aWFsU3RhdGUuanM/ZTJhZmUxOSIsIndlYnBhY2s6Ly8vLi9hY3Rpb25zL2F1dGhBY3Rpb25zLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vY29uZmlnL2VudkNvbmZpZy5qcz9lMmFmZTE5Iiwid2VicGFjazovLy8uL3BhZ2VzL19kb2N1bWVudC5qcz9lMmFmZTE5Iiwid2VicGFjazovLy8uL2NvbmZpZy9jb25maWcuanNvbj9lMmFmZTE5Iiwid2VicGFjazovLy8uL2FjdGlvbnMvYWN0aW9uVHlwZXMuanM/ZTJhZmUxOSIsIndlYnBhY2s6Ly8vLi9hY3Rpb25zL3BhZ2luYXRvci5qcz9lMmFmZTE5Iiwid2VicGFjazovLy8uL2FwaS9hdXRoQXBpLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vbWlkZGxld2FyZS9hcGlJbnRlcmNlcHRlci5qcz9lMmFmZTE5Iiwid2VicGFjazovLy8uL3JlZHVjZXJzL2F1dGhSZWR1Y2VyLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vcmVkdWNlcnMvZWRpdEFjY291bnRSZWR1Y2VyLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vcmVkdWNlcnMvcGFnZVJlZHVjZXIuanM/ZTJhZmUxOSIsIndlYnBhY2s6Ly8vLi9yZWR1Y2Vycy90aW1lUmVkdWNlci5qcz9lMmFmZTE5Iiwid2VicGFjazovLy8uL3N0b3JlLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vdXRpbHMvYXV0aFV0aWxzLmpzP2UyYWZlMTkiLCJ3ZWJwYWNrOi8vLy4vdXRpbHMvZXJyb3JIYW5kbGVycy5qcz9lMmFmZTE5Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7UUFFRSxDQURBO1lBRUE7UUFDRTtxQkFFRjs7ZUFDQTtZQUNFO1VBQ0E7WUFBUSxPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVEw7Ozs7QUFHUDs7Ozs7OzBCQUFhLGtDQUFhOzswRUFBUSxpQkFBTTs7O3VEQUNoQztBQUQwQix3QkFDaEIsa0JBQVEsV0FBVyw2QkFFNUI7c0JBQ0Msc0JBQ047eUJBQVMsUUFBUTtBQURqQjs7OztBQUpzQjs7OztBQVMxQixDQVRPOztBQVNBLElBQU0sa0NBQWE7OzJFQUFNLGtCQUFNOzs7eURBQzlCO0FBRHdCLHdCQUNkLGtCQUFRLHNDQUNqQixtQkFBUyxFQUFFLE1BQU0sc0JBQVksU0FBUyxTQUFTOzs7O0FBRjlCOzs7O0FBSzFCOztBQUFPLElBQU0sMEJBQVM7U0FBTyxFQUFFLE1BQU0sc0JBQVk7QUFFakQ7O0FBQU8sSUFBTSw0Q0FBa0I7U0FBUTtBQUNyQztZQUNRLHNCQUNOO1lBRk8sSUFDUDtBQUYyQjtBQU0vQjs7QUFBTyxJQUFNLDhDQUFtQjs7MkVBQVEsa0JBQU07Ozt5REFDdEM7QUFEZ0MseUJBQ3JCLGtCQUFRLGFBQWEsOEJBRS9CO3NCQUNDLHNCQUNOO3lCQUFTLFNBQVM7QUFEbEI7Ozs7QUFKNEI7Ozs7QUFTaEM7O0FBQU8sSUFBTSxrREFBcUI7U0FBUSxvQkFDeEM7UUFBTSxVQUFVLGtCQUFRLG1CQUV4Qjs7V0FBTyxTQUNMO1lBQU0sc0JBQ047ZUFFSDtBQVBpQztBQVNsQzs7QUFBTyxJQUFNLDRDQUFrQiwrQkFDN0I7U0FDRTtVQUFNLHNCQUNOO1VBRUg7QUFFRDs7QUFBTyxJQUFNLGtDQUFhO1NBQVEsb0JBQ2hDO1FBQU0sVUFBVSxrQkFBUSxXQUV4Qjs7O1lBQ1Esc0JBQ047ZUFBUyxRQUVaO0FBSEcsS0FESztBQUhpQjtBQVMxQjs7QUFBTyxJQUFNLGtDQUFhO1NBQVMsb0JBQ2pDO1FBQU0sVUFBVSxrQkFBUSxXQUV4Qjs7O1lBQ1Esc0JBQ047ZUFBUyxRQUVaO0FBSEcsS0FESztBQUhpQjtBQVMxQjs7QUFBTyxJQUFNLHdDQUFnQjtTQUFpQixvQkFDNUM7UUFBTSxVQUFVLGtCQUFRLGNBRXhCOzs7WUFDUSxzQkFDTjtlQUFTLFFBRVo7QUFIRyxLQURLO0FBSG9CO0FBQXRCLEU7Ozs7Ozs7Ozs7Ozs7OztBQ3BFUCxJQUFNLE9BQU8sYUFBWSxLQUFhO0FBQ3RDLElBQU0sU0FBUzs7QUFTZjs7Ozs7OztrQkFDRTtvREFBYSxPQUFPLE9BQU8sV0FBVyxPQUN0QztzREFDQTt1REFBZ0IsT0FDaEI7NkNBQU0sQ0FBQyxRQUFRLGFBQWEsbUJBQW1CLGNBQWMsYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RoQzs7OztBQUN4Qjs7OztBQUNFOztBQUNBOztBQUNGOzs7Ozs7SUFFRDs7OzRFQUNNLFNBQ1I7VUFBTSxRQUNOO1VBQU0sT0FBTyxNQUFNLGNBQWMsZ0JBQUMsOEJBQ2xDO1VBQU0sWUFBWSxNQUVsQjs7QUFDRSxtREFDRSxzQkFBQyw4QkFDQzthQUVFO2NBQ0EsV0FGQTtjQUlGLGdGQUFNLE1BQUssc0JBQXFCLEtBQUksY0FBYSxNQUNqRDtlQUVFLElBREE7Y0FFQTthQUNBO2NBRUYsNERBQVEsb0JBQ1AsZ0JBQ0QsbURBQU0sS0FBSSxjQUFhLE1BQUssWUFBVyxNQUV6QyxnRUFDRyxNQUNELHNCQUFDLG9DQUlSOztBQUdIOztrQkFBeUIsa0RBQVcsWTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeENwQztBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7QUNKQSxJQUFNO0FBRUo7UUFFQSxNQUhBOztBQUlBO2lCQUNBO29CQUNBO2VBQ0E7YUFDQTtXQUNBO2VBQ0E7ZUFDQTtrQkFFQTs7QUFDQTtrQkFDQTtlQUVBOztBQUNBO2dCQUNBO2dCQUdGOztrQkFBZSxZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZCUjs7OztBQUdQOzs7O0FBQU8sSUFBTSw0Q0FBa0IseUJBQUMsVUFBVSxXQUN4QztBQUNBO01BQU0sY0FBYyxxQkFBQyxVQUFVLFdBQVcsTUFDeEM7V0FDRTtZQUFNLHNCQUNOO2VBQ0U7Y0FFRjs7WUFDRTtrQkFDQTttQkFHTDtBQUVEOztBQUNBO01BQU0sY0FBYyxxQkFBQyxXQUFXLE1BQU0sU0FDcEM7V0FDRTtZQUFNLHNCQUNOO2VBQ0U7Y0FDQTtpQkFFRjs7WUFDRTttQkFHTDtBQUNEO0FBQ0E7TUFBTSxRQUFRLGlCQUE2QjtRQUFBLGdLQUN6QztZQUFRLE9BQ047V0FBSyxzQkFDSDtzQ0FDSyxJQURMLHFDQUVHLFdBQU8sS0FBSyx5Q0FDVixXQUFPLFFBQVE7ZUFFZCxFQURBO29CQUtSOztXQUFLLHNCQUNIO3NDQUNLLElBREwscUNBRUcsSUFGSCx5Q0FHSyxXQUFPLFFBQVE7c0JBQ0YsUUFBUSxRQUFRLElBQUk7bUJBQVMsTUFBTTtBQUMvQyxXQURLLENBQUw7b0JBS1I7O0FBQ0U7ZUFFTDtBQUVEOztBQUNBO01BQU0sY0FBYztRQUFDLGtGQUFjLE1BQUcsNkVBQVMsR0FDNUMsY0FBTyxTQUFTLHNCQUNiLHNCQUFPLFFBQ1AsT0FIYztBQUtwQjs7TUFBTSxrQkFBa0I7V0FBVyxZQUE2QjtVQUFBLGdLQUM5RDtVQUFJLE9BQU8sT0FBTyxTQUFTLGFBQ3pCO2VBQ0Q7QUFDRDtVQUFJLE9BQU8sS0FBSyxhQUFhLFVBQzNCO2VBQU8sUUFBUSxPQUNoQjtBQUVEOztVQUFJLE9BQU8sS0FBSyxjQUFjLFdBQzVCO2VBQU8sUUFBUSxPQUNoQjtBQUVEOzthQUVBOztBQUNBO0FBQ0E7QUFDRDtBQWpCdUI7QUFtQnhCOztNQUFNLGVBQWUsd0JBQTZCO1FBQUEsZ0tBQ2hEO1lBQVEsT0FDTjtXQUFLLHNCQUNIO1lBQUksU0FBUyxHQURmLHNHQUVFOzBEQUFpQixPQUFPLFFBQVEsbUhBQVM7Z0JBQUEsYUFDdkM7NENBQ0ssSUFETCxzQ0FFRyxTQUFLLEtBRVQ7QUFQSDs7Ozs7Ozs7Ozs7OztBQVFFO3NDQUNLLElBQ0EsT0FFUDs7QUFDRTtlQUVMO0FBRUQ7O01BQU0sVUFDSjtXQUVFLEtBREE7aUJBS0o7O1NBQ0U7aUJBQ0E7aUJBQ0E7YUFDQTtrQkFBYyxnQkFFakI7QUFqSE0sRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSEE7Ozs7QUFDQTs7Ozs7O0lBRUQ7Ozs7cUZBQ3FCLFE7Ozt5REFDakI7c0JBQVMsb0JBQUksbURBQ1osMkNBQU07MEJBRVgsTUFEQTsyQkFFRTtvQ0FFRjs7QUFDQTsrQkFBYSxXQUNiO3dCQUFNLHlCQUFlOzs7Ozs7Ozs7OzsyREFLakI7O3NCQUFTLG9CQUFJLHFEQUNaLDJDQUFNOzBCQUVYLEtBREE7MkJBRUU7b0NBRUY7OytCQUFhOzs7Ozs7OztzRkFJVSxTOzs7MkRBQ25CO3NCQUFTLG9CQUFJLHlGQUNVOzBCQUUzQixNQURBOzJCQUVFO29DQUVGOzsrQkFBYSxXQUNiO3dCQUFNLHlCQUFlLFFBTkE7QUFBakIsa0VBU0MsVTs7Ozs7Ozs7Ozs7MkRBSUQ7O3NCQUFTLG9CQUFJLHdGQUNVOzBCQUUzQixLQURBOytCQUNhLFlBRlE7QUFBakIsa0VBS0MsVTs7Ozs7Ozs7c0ZBR2dCLFM7OzsyREFDakI7c0JBQVMsb0JBQUksd0ZBQ1U7MEJBRTNCLE1BREE7MkJBRUU7b0NBRUY7OytCQUNBO3dCQUFNLHlCQUFlLFFBTkE7QUFBakIsa0VBU0MsVTs7Ozs7Ozs7c0ZBR2dCLFM7OzsyREFDakI7c0JBQVMsb0JBQUksK0ZBQ1U7MEJBRTNCLE1BREE7MkJBRUU7b0NBRUY7OytCQUNBO3dCQUFNLHlCQUFlLFNBTkE7QUFBakIsa0VBU0MsVTs7Ozs7Ozs7c0ZBR21CLFM7OzsyREFDcEI7c0JBQVMsb0JBQUksOEZBQ1U7MEJBRTNCLE1BREE7MkJBRUU7b0NBRUY7OytCQUNBO3dCQUFNLHlCQUFlLGlCQU5BO0FBQWpCLGtFQVNDLFU7Ozs7Ozs7O0FBSVg7O2tCQUFlLFE7Ozs7Ozs7Ozs7Ozs7Ozs7a0JDdkZBLGdCQUF3Qjt1QkFBQSxnQkFDckM7U0FBTzs7NkVBQVEsaUJBQU07Ozs7b0JBV2YsR0FBQyxPQUFPLFdBQVcsQ0FBQyxPQUFPLFFBQVE7O3dDQUM5QixlQUFLO29EQUlXLGNBQU87QUFBeEIsMkRBU0EsNkNBQWtCLFVBQVUsVUFBVSxPQUFPO21DQUVoQyxnQkFBUztBQUF0Qix5Q0FPRixPQUFLLFNBQVMsT0FBTyxTQUFTOztBQUNoQztBQUNNO0FBcENHO3dCQXFDRCxPQUNOOzsyQkFDUyxLQUNQOzRCQUFRLEtBSVo7O0FBUmtCO0FBR2QsbUJBRkYsR0FRRixTQUVBOztBQS9DUzs7eUJBaURBLEtBQ1AsS0FEQTswQkFDUSxLQUFLO29CQUliLE9BQUssU0FBUyxPQUFPLFNBQVM7O0FBQzFCO0FBdkRHO3dCQXdERCxPQUNOO3dCQUFNLEtBR1I7O0FBTGtCO0FBQ2hCLGtCQUtGLFNBQVMsYUE3REEsdUJBOERGLGVBQUssWUFHZDs7b0JBQUksS0FBSyxTQUFTLE9BQU8sU0FBUyxXQUNoQzswQkFBUSxJQUNSOzBCQUFRLElBRUY7O0FBSnFDLGdDQUl2QiwrQkFBZSxLQUVuQzs7MkJBQ0U7MEJBQU0sc0JBQ047cURBRUg7QUFFSzs7QUE3RUs7d0JBOEVILE9BQ047d0JBQU0sS0FHUjs7QUFDQTtBQUVBOztBQVJrQjtBQUNoQixrQkFRRixTQUFTLFdBdEZFLHVCQXVGSixlQUFLO21FQUVaOzt3QkFBUSxJQUNSO3VFQUF5QixVQTFGZDs7OztBQUFSOzs7O0FBOEZSOzs7Ozs7Ozs7Ozs7Ozs7QUF2R1E7O0FBR1A7O0FBS0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUk87Ozs7QUFHUDs7Ozs7O0FBQU8sSUFBTSxvQ0FBYyx1QkFBdUM7TUFBQSw0RUFBOUIsdUJBQThCLDRCQUNoRTtVQUFRLE9BQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtTQUFLLHNCQUNIO2FBQU8sc0JBQWMsSUFBSSw4QkFDcEIsV0FBTzt5QkFHZCxJQUZJOztTQUVDLHNCQUNIO2FBQU8sc0JBQWMsSUFBSSw4QkFDcEIsV0FBTzt5QkFHZCxJQUZJOztTQUVDLHNCQUNIO2FBQ0U7eUJBRUo7O0FBQ0U7YUFFTDtBQXZCTSxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIQTs7OztBQUdQOzs7Ozs7QUFBTyxJQUFNLGtEQUFxQiw4QkFHN0I7TUFBQSw0RUFGSyx1QkFFTCxtQ0FDSDtVQUFRLE9BQ047U0FBSyxzQkFDSDthQUFPLHNCQUFjLElBQUk7Y0FDakIsT0FFVixJQUZJOztBQUdGO2FBRUw7QUFaTSxFOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0hBOzs7O0FBRUU7Ozs7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7O0FBQU8sSUFBTSxrQ0FBYSxnQ0FBZ0IsV0FBVztBQVpyRCw0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7Ozs7OztBQUFPLElBQU0sb0NBQWMsdUJBQXVDO01BQUEsNEVBQTlCLHVCQUE4Qiw0QkFDaEU7VUFBUSxPQUNOO1NBQ0U7YUFBTyxzQkFBYyxJQUFJLE9BQU8sT0FDbEM7QUFDRTthQUVMO0FBUE0sRTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEZ0M7O0FBQ2hDOzs7O0FBQ0U7O0FBQ1c7O0FBQ1g7O0FBQ0E7O0FBQ1c7O0FBQ1g7O0FBQ0Y7Ozs7QUFHUDs7OztBQUFPLElBQU0sZ0NBQVkscUJBQXVCO01BQUEsbUZBQzlDO0FBQ0E7TUFBTSxXQUFXO0FBRWY7QUFDQSw0QkFGQTtBQUdBO0FBQ0E7QUFDQTtnQkFBWSx3QkFHZDs7TUFBSSxNQUFNLGFBQVksSUFFdEI7O01BQUksT0FBTyxXQUFXLGVBQWUsUUFBUSxlQUMzQztXQUNFLHdCQUNBLFVBQ0EsK0RBRUg7QUFFRDs7U0FDRSx3QkFDQSxVQUNBLGNBRUg7QUExQk0sRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1RBOzs7O0FBQ0E7Ozs7QUFLTDs7Ozs7O0FBY0Y7Ozs7O0FBQU8sSUFBTSxrQ0FBYSxzQkFDeEI7TUFBSSxDQUFDLFFBQVEsU0FDWDtBQUNEO0FBQ0Q7QUFDQTtBQUNBO0FBRUE7O1NBQU8sYUFBYSxRQUFRLFVBQVUsS0FDdkM7QUFUTTtBQVVQLElBQU0sY0FBYyxxQkFBQyxVQUF5QixVQUM1QztNQUFJLENBQUMsVUFBVSxPQUNmO1NBQ0csU0FESSxNQUNFLFVBQ1Y7QUFKRDs7QUFNQSxJQUFNLFVBQVUsaUJBQUMsVUFBa0IsS0FDakM7TUFBSSxDQUFDLFVBQVUsT0FDZjtrQkFBZ0IsTUFBTSxLQUFLLEtBQUs7V0FBSyxFQUFFLE9BQU8sV0FBYyxNQUE1QjtBQUNqQyxHQURRO0FBRlQ7O0FBWUE7Ozs7Ozs7QUFBTyxJQUFNLGtEQUFxQiw0QkFBQyxTQUNqQztNQUFJLENBQUMsUUFBUSxRQUFRLFFBQ25CO1dBQ0Q7QUFFRDs7TUFBTSxZQUFvQixRQUFRLFFBQ2xDO1NBQU8sWUFBWSxRQUFRLFdBQVcsUUFDdkM7QUFQTTs7QUFlUDs7Ozs7O0FBQU8sSUFBTSx3REFBd0IsK0JBQUMsU0FDcEM7VUFBUSxJQUNSO1VBQVEsSUFFUjs7TUFBSSxDQUFDLFNBQ0g7V0FDRDtBQUNEO1VBQVEsSUFFUjs7VUFBUSxJQUFJLFFBQ1o7VUFBUSxJQUVSOztTQUFPLFlBQVksUUFBUSxRQUFRLElBQUksUUFDeEM7QUFiTTs7QUFzQlA7Ozs7Ozs7QUFBTyxJQUFNLHNFQUErQixzQ0FBQyxZQUMzQztNQUFJLENBQUMsWUFBWSxPQUVqQjs7TUFBTSxhQUFhLFdBQ25CO1NBQ0Q7QUFMTTs7QUFnQlA7Ozs7Ozs7OztBQUFPLElBQU0sZ0RBQW9CLDJCQUFDLFlBQWlCLFFBQ2pEO01BQU0sVUFBMkIsNkJBRWpDOztNQUFJLFNBQ0Y7WUFBUSxJQUNSO1dBQU8sc0JBQ1I7QUFIRCxTQUlFO1lBQVEsSUFDUjtXQUFPLG1CQUNSO0FBQ0Y7QUFWTTs7QUFtQlA7Ozs7Ozs7QUFBTyxJQUFNLGdFQUE0QixtQ0FBQyxTQUN4QztNQUFNLGVBRU47O01BQU0sWUFBd0IsWUFBWSxRQUFRLFFBQVEsSUFBSSxRQUM5RDtNQUFNLE1BQU0sU0FBUyxPQUVyQjs7TUFBTSxhQUF5QixZQUFZLFFBQVEsUUFBUSxJQUFJLFVBQy9EO01BQU0sT0FBTyxXQUFXLE9BRXhCOztlQUFhLEtBQUssS0FDbEI7U0FBTyxhQUFhLFdBQVcsUUFBUSxLQUN4QztBQVhNOztBQXNCUDs7Ozs7Ozs7O0FBQU8sSUFBTSxvQ0FBYyxxQkFBQyxZQUFpQixRQUMzQztNQUFJLENBQUMsUUFDSDtXQUNEO0FBRUQ7O01BQUksQ0FBQyxZQUNIO1dBQU8sT0FBTyxRQUNmO0FBRUQ7O01BQU0sVUFBMkIsNkJBRWpDOztNQUFJLFNBQ0Y7WUFBUSxJQUNSO1dBQU8sMEJBQ1I7QUFIRCxTQUlFO1lBQVEsSUFDUjtXQUFPLE9BQU8sUUFDZjtBQUNGO0FBbEJNOztBQTRCUDs7Ozs7Ozs7QUFBTyxJQUFNLDBDQUFpQix3QkFBQyxPQUM3QjtNQUFJLENBQUMsT0FDSDtXQUNEO0FBRUQ7O01BQU0sZUFBcUIseUJBQzNCO0FBQ0E7TUFBTSxjQUFjLENBQUMsUUFBUSxTQUFTLE9BRXRDOzs2QkFDRyxjQURJLE9BQ0csVUFBQztXQUFRLFlBQVksU0FBUztBQUNyQyxHQUZJLFNBRUcsVUFBQyxLQUFLLEtBQ1o7a0NBQ0ssSUFETCxtQ0FFRyxJQUZILEtBRVMsYUFFVjtBQVBJLEtBU1A7O0FBQ0Q7QUFuQk07O0FBNEJQOzs7Ozs7O0FBQU8sSUFBTSx3Q0FBZ0IsdUJBQUMsTUFDNUI7TUFBSSxLQUFLLEtBQ1A7UUFBTSxjQUFzQix3QkFDNUI7UUFBTSxVQUFtQixLQUFLLE1BQU0sYUFFcEM7O1FBQUksU0FDRjthQUNEO0FBQ0Y7QUFFRDs7U0FDRDtBQVhNOztBQXVCUDs7Ozs7Ozs7OztBQUFPLElBQU07d0VBQTBCLGlCQUFPLE9BQW1COzs7cURBQy9EO29CQUFRLElBQUksdUJBQ1AsSUFGZ0M7O29DQUc1QixnQkFBTSxTQUFTO2dCQUlwQixlQUFjOztBQUNoQjtvQkFBUSxJQUFJLG1CQVJ1QixvQ0FVcEIsYUFBTSxTQUFTLHFDQUFtQjs7K0RBRS9DOztvQkFBUSxJQUFJLHVCQVpxQjs7OztBQUExQjs7O0FBQU47O0FBMkJQOzs7Ozs7Ozs7O0FBQU8sSUFBTTt5RUFBMEIsa0JBQU8sT0FBbUIsTUFBWTs7O3VEQUMzRTtBQVFBOzs7Ozs7OztvQkFBUSxJQUFJLHVCQUF1QixNQUU5QixJQVhnQzs7cUNBWTVCLGdCQUFNLFNBQVMsa0NBR3hCOztBQUdBOzs7b0JBQVEsSUFFUjs7QUFDQTtBQUNBO0FBdEJxQzs4Q0F1QjlCLE1BQU0sU0FBUyxrQ0FBZ0I7Ozs7QUF2QjNCOzs7QUFBTixJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFQRTs7QUFDRjs7OztBQUNFOzs7OztBQVVUOzs7Ozs7Ozs7QUFBTyxJQUFNO3dFQUF3QixpQkFBTyxHQUFHOzs7cURBQzdDO29CQUFRLElBQ1I7b0JBQVEsSUFFUjs7Z0JBQUksRUFBRSxRQUNKO3VDQUFPLE1BQU0sVUFBVSxFQUN2QjtBQUNBO3NCQUNFLElBR0Y7OzhCQUFPLG9CQUNSO0FBRUQ7O2dCQUFJLEVBQUUsU0FDSjt1Q0FBTyxNQUFNLFVBQVUsRUFDeEI7QUFoQmtDOzs7O0FBQXhCOzs7QUFBTjs7QUE2QlA7Ozs7Ozs7Ozs7QUFBTyxJQUFNO3lFQUFvQixrQkFBTyxVQUFVLFVBQVU7Ozt1REFDMUQ7b0JBQVEsSUFDUjtvQkFBUSxJQUFJLFNBRU47O0FBSnlCO3VCQUtwQixPQUNUO3VCQUdGOztBQUxjO0FBQ1osb0JBS0UsU0FBUyxXQUFXLE9BQU8sZUFBZTs7QUFDNUM7a0JBQU0sVUFBVSxpQ0FDVixNQVp1QjtnQkFlM0IsV0FBUyxXQUFXOztBQUN0QjtrQkFBTSxVQUNOO2tCQUFNLFVBQVUscUJBakJhLG9CQWtCdkIsZ0JBQVM7QUFDVCxrQkFuQnVCO2dCQXNCM0IsV0FBUyxXQUFXOztpQ0FDQyxnQkFBUztBQUExQiwwQ0FNRixPQUFNLFFBQVEsU0FBUzs7QUFDbkIsNEJBQVM7QUFFVCwyQkFBUztnQkFJZixXQUFTLFdBQVc7O0FBQ3RCO2tCQUFNLFVBQVUsU0FBUyxXQUNuQixNQXRDdUI7Ozs7QUFBcEI7OztBQUFOLEkiLCJmaWxlIjoiYnVuZGxlcy9wYWdlcy9fZG9jdW1lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCB7XG4gIHRpbWU6IDAsXG4gIGlzU2F2aW5nOiBmYWxzZSxcbiAgdXNlcjoge1xuICAgIGlzQXV0aGVudGljYXRlZDogZmFsc2VcbiAgfSxcbiAgdXNlckFjY291bnQ6IHt9LFxuICBmaWx0ZXJlZDoge1xuICAgIHRhZ3M6IFtdLFxuICAgIHN0b3JlczogW11cbiAgfVxufVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vcmVkdWNlcnMvaW5pdGlhbFN0YXRlLmpzIiwiaW1wb3J0IGFjdGlvblR5cGVzIGZyb20gJy4vYWN0aW9uVHlwZXMnXG5pbXBvcnQgYXV0aEFwaSBmcm9tICcuLi9hcGkvYXV0aEFwaSdcblxuZXhwb3J0IGNvbnN0IHNpZ25pblVzZXIgPSB1c2VyID0+IGFzeW5jIGRpc3BhdGNoID0+IHtcbiAgY29uc3QgcmVxdWVzdCA9IGF1dGhBcGkuc2lnbkluVXNlcih1c2VyKVxuXG4gIHJldHVybiBkaXNwYXRjaCh7XG4gICAgdHlwZTogYWN0aW9uVHlwZXMuTE9HX1VTRVJfSU4sXG4gICAgcGF5bG9hZDogcmVxdWVzdCAvLyByZXF1ZXN0ID0gUHJvbWlzZSwgbXVzdCBzZW5kIGRhdGEgb24ga2V5ICdwYXlsb2FkYFxuICB9KVxufVxuXG5leHBvcnQgY29uc3QgbG9nVXNlck91dCA9ICgpID0+IGFzeW5jIGRpc3BhdGNoID0+IHtcbiAgY29uc3QgcmVxdWVzdCA9IGF1dGhBcGkuc2lnbk91dFVzZXIoKVxuICByZXR1cm4gZGlzcGF0Y2goeyB0eXBlOiBhY3Rpb25UeXBlcy5MT0dfT1VULCBwYXlsb2FkOiByZXF1ZXN0IH0pXG59XG5cbmV4cG9ydCBjb25zdCBsb2dPdXQgPSAoKSA9PiAoeyB0eXBlOiBhY3Rpb25UeXBlcy5MT0dfT1VUIH0pXG5cbmV4cG9ydCBjb25zdCBzYXZlVXNlclRvUmVkdXggPSB1c2VyID0+IGRpc3BhdGNoID0+XG4gIGRpc3BhdGNoKHtcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5TQVZFX1VTRVIsXG4gICAgdXNlclxuICB9KVxuXG5leHBvcnQgY29uc3QgYXV0aGVudGljYXRlVXNlciA9IHVzZXIgPT4gYXN5bmMgZGlzcGF0Y2ggPT4ge1xuICBjb25zdCByZXNwb25zZSA9IGF1dGhBcGkucmVnaXN0ZXJVc2VyKHVzZXIpXG5cbiAgcmV0dXJuIGRpc3BhdGNoKHtcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5DUkVBVEVfVVNFUixcbiAgICBwYXlsb2FkOiByZXNwb25zZSAvLyByZXF1ZXN0ID0gUHJvbWlzZSwgbXVzdCBzZW5kIGRhdGEgb24ga2V5ICdwYXlsb2FkYFxuICB9KVxufVxuXG5leHBvcnQgY29uc3QgcmVmcmVzaFRva2VuQWN0aW9uID0gdXNlciA9PiBkaXNwYXRjaCA9PiB7XG4gIGNvbnN0IHJlcXVlc3QgPSBhdXRoQXBpLmZldGNoUmVmcmVzaFRva2Vucyh1c2VyKVxuXG4gIHJldHVybiBkaXNwYXRjaCh7XG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfTkVXX1RPS0VOUyxcbiAgICBwYXlsb2FkOiByZXF1ZXN0XG4gIH0pXG59XG5cbmV4cG9ydCBjb25zdCBsb2FkQWNjb3VudEZvcm0gPSB1c2VyID0+IHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5MT0FEX1VTRVJfREFUQSxcbiAgICB1c2VyXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHVwZGF0ZVVzZXIgPSB1c2VyID0+IGRpc3BhdGNoID0+IHtcbiAgY29uc3QgcmVxdWVzdCA9IGF1dGhBcGkudXBkYXRlVXNlcih1c2VyKVxuXG4gIHJldHVybiBkaXNwYXRjaCh7XG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX1VTRVIsXG4gICAgcGF5bG9hZDogcmVxdWVzdCAvLyByZXF1ZXN0ID0gUHJvbWlzZSwgbXVzdCBzZW5kIGRhdGEgb24ga2V5ICdwYXlsb2FkYFxuICB9KVxufVxuXG5leHBvcnQgY29uc3QgZm9yZ290VXNlciA9IGVtYWlsID0+IGRpc3BhdGNoID0+IHtcbiAgY29uc3QgcmVxdWVzdCA9IGF1dGhBcGkuZm9yZ290VXNlcihlbWFpbClcblxuICByZXR1cm4gZGlzcGF0Y2goe1xuICAgIHR5cGU6IGFjdGlvblR5cGVzLkZPUkdPVF9VU0VSLFxuICAgIHBheWxvYWQ6IHJlcXVlc3QgLy8gcmVxdWVzdCA9IFByb21pc2UsIG11c3Qgc2VuZCBkYXRhIG9uIGtleSAncGF5bG9hZGBcbiAgfSlcbn1cblxuZXhwb3J0IGNvbnN0IHJlc2V0UGFzc3dvcmQgPSBwYXNzd29yZFRva2VuID0+IGRpc3BhdGNoID0+IHtcbiAgY29uc3QgcmVxdWVzdCA9IGF1dGhBcGkucmVzZXRQYXNzd29yZChwYXNzd29yZFRva2VuKVxuXG4gIHJldHVybiBkaXNwYXRjaCh7XG4gICAgdHlwZTogYWN0aW9uVHlwZXMuUkVTRVRfUEFTU1dPUkQsXG4gICAgcGF5bG9hZDogcmVxdWVzdCAvLyByZXF1ZXN0ID0gUHJvbWlzZSwgbXVzdCBzZW5kIGRhdGEgb24ga2V5ICdwYXlsb2FkYFxuICB9KVxufVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vYWN0aW9ucy9hdXRoQWN0aW9ucy5qcyIsImNvbnN0IHByb2QgPSBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nXG5jb25zdCBjb25maWcgPSByZXF1aXJlKCcuL2NvbmZpZy5qc29uJylcblxuLypcbmh0dHBzOi8vdGVzdG9uZS5ub3cuc2gvYXBpID0gbXlhcGkubncuc2gvYXBpXG5iZWNhdXNlIG9mIHRoaXMgdHJhbnNsYXRpb24gLSB0aGUgcm91dGVzIG9uIHRoZSBBUEkgbmVlZCB0byBiZSBsb29raW5nIGZvciAvYXBpL19fcm91dGVfX1xuU2luY2UgTm93IGRvZXMgaXQgdGhpcyB3YXkgLSBpbiBvcmRlciB0byBoYXZlIG91ciBhcHAgcmVhZHkgZm9yIFByb2QgZGVwbG95bWVudCwgYWRkaW5nIGFwaSBvbiB0aGUgZW5kIG9mXG5sb2NhbEhvc3Q6MzAwMC9hcGkgLT4gdHJhbnNsYXRlcyB0byBodHRwOi8vbG9jYWxob3N0Ojc3NzcgZHVlIHRvIGh0dHAtcHJveHkgLSBzbyBub3cgb3VyIG9yaWdpbmFsIC9hcGkvX19yb3V0ZV9fXG53aWxsIHN0aWxsIHdvcmsgaW4gYm90aCBEZXYgYW5kIFByb2R1Y3Rpb25cbiovXG5leHBvcnQgZGVmYXVsdCB7XG4gIEJBQ0tFTkRfVVJMOiBwcm9kID8gY29uZmlnLlBST0RfVVJMIDogY29uZmlnLkRFVl9VUkwsXG4gIFdFQlNJVEVfVElUTEU6ICdOb3cgVGhhdHMgRGVsaWNpb3VzIScsXG4gIFJFRlJFU0hfV0lORE9XOiBjb25maWcuUkVGUkVTSF9XSU5ET1csXG4gIFRBR1M6IFsnV2lmaScsICdPcGVuIExhdGUnLCAnRmFtaWx5IEZyaWVuZGx5JywgJ1ZlZ2V0YXJpYW4nLCAnTGljZW5zZWQnXVxufVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vY29uZmlnL2VudkNvbmZpZy5qcyIsImltcG9ydCBEb2N1bWVudCwgeyBIZWFkLCBNYWluLCBOZXh0U2NyaXB0IH0gZnJvbSAnbmV4dC9kb2N1bWVudCdcbmltcG9ydCB3aXRoUmVkdXggZnJvbSAnbmV4dC1yZWR1eC13cmFwcGVyJ1xuaW1wb3J0IHsgaW5pdFN0b3JlIH0gZnJvbSAnLi4vc3RvcmUnXG5pbXBvcnQgeyBTZXJ2ZXJTdHlsZVNoZWV0IH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXG5pbXBvcnQgZW52IGZyb20gJy4uL2NvbmZpZy9lbnZDb25maWcnXG5cbmNsYXNzIE15RG9jdW1lbnQgZXh0ZW5kcyBEb2N1bWVudCB7XG4gIHJlbmRlciAoKSB7XG4gICAgY29uc3Qgc2hlZXQgPSBuZXcgU2VydmVyU3R5bGVTaGVldCgpXG4gICAgY29uc3QgbWFpbiA9IHNoZWV0LmNvbGxlY3RTdHlsZXMoPE1haW4gLz4pXG4gICAgY29uc3Qgc3R5bGVUYWdzID0gc2hlZXQuZ2V0U3R5bGVFbGVtZW50KClcblxuICAgIHJldHVybiAoXG4gICAgICA8aHRtbD5cbiAgICAgICAgPEhlYWQ+XG4gICAgICAgICAgPGxpbmtcbiAgICAgICAgICAgIHJlbD0nc2hvcnRjdXQgaWNvbidcbiAgICAgICAgICAgIHR5cGU9J2ltYWdlL3BuZydcbiAgICAgICAgICAgIGhyZWY9Jy9zdGF0aWMvaW1hZ2VzL2ljb25zL2RvdWdobnV0LnBuZydcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxsaW5rIGhyZWY9Jy9zdGF0aWMvdG9hc3RyLmNzcycgcmVsPSdzdHlsZXNoZWV0JyB0eXBlPSd0ZXh0L2NzcycgLz5cbiAgICAgICAgICA8bGlua1xuICAgICAgICAgICAgYXN5bmNcbiAgICAgICAgICAgIGhyZWY9Jy8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1PcGVuK1NhbnMnXG4gICAgICAgICAgICByZWw9J3N0eWxlc2hlZXQnXG4gICAgICAgICAgICB0eXBlPSd0ZXh0L2NzcydcbiAgICAgICAgICAvPlxuICAgICAgICAgIDx0aXRsZT57ZW52LldFQlNJVEVfVElUTEV9PC90aXRsZT5cbiAgICAgICAgICB7c3R5bGVUYWdzfVxuICAgICAgICAgIDxsaW5rIHJlbD0nc3R5bGVzaGVldCcgdHlwZT0ndGV4dC9jc3MnIGhyZWY9Jy9zdGF0aWMvc3R5bGVzLmNzcycgLz5cbiAgICAgICAgPC9IZWFkPlxuICAgICAgICA8Ym9keT5cbiAgICAgICAgICB7bWFpbn1cbiAgICAgICAgICA8TmV4dFNjcmlwdCAvPlxuICAgICAgICA8L2JvZHk+XG4gICAgICA8L2h0bWw+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IHdpdGhSZWR1eChpbml0U3RvcmUpKE15RG9jdW1lbnQpXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9wYWdlcy9fZG9jdW1lbnQuanM/ZW50cnkiLCJtb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJERVZfVVJMXCI6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaVwiLFxuXHRcIlBST0RfVVJMXCI6IFwiaHR0cHM6Ly90ZXN0b25lLm5vdy5zaFwiLFxuXHRcIlJFRlJFU0hfV0lORE9XXCI6IDE1XG59O1xuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vY29uZmlnL2NvbmZpZy5qc29uXG4vLyBtb2R1bGUgaWQgPSA1NTBcbi8vIG1vZHVsZSBjaHVua3MgPSAxIiwiY29uc3QgYWN0aW9uVHlwZXMgPSB7XG4gIC8vIE1vbWVudFxuICBUSUNLOiAnVElDSycsXG5cbiAgLy8gQVVUSFxuICBSRUZSRVNIX1RPS0VOOiAnUkVGUkVTSF9UT0tFTicsXG4gIEZFVENIX05FV19UT0tFTlM6ICdGRVRDSF9ORVdfVE9LRU5TJyxcbiAgQ1JFQVRFX1VTRVI6ICdDUkVBVEVfVVNFUicsXG4gIFNBVkVfVVNFUjogJ1NBVkVfVVNFUicsXG4gIExPR19PVVQ6ICdMT0dfT1VUJyxcbiAgTE9HX1VTRVJfSU46ICdMT0dfVVNFUl9JTicsXG4gIEZPUkdPVF9VU0VSOiAnRk9SR09UX1VTRVInLFxuICBSRVNFVF9QQVNTV09SRDogJ1JFU0VUX1BBU1NXT1JEJyxcblxuICAvLyBVc2VyIEFjY291bnRcbiAgTE9BRF9VU0VSX0RBVEE6ICdMT0FEX1VTRVJfREFUQScsXG4gIFVQREFURV9VU0VSOiAnVVBEQVRFX1VTRVInLFxuXG4gIC8vIFBBR0lOQVRJT05cbiAgUkVRVUVTVF9QQUdFOiAnUkVRVUVTVF9QQUdFJyxcbiAgUkVDRUlWRV9QQUdFOiAnUkVDRUlWRV9QQUdFJ1xufVxuXG5leHBvcnQgZGVmYXVsdCBhY3Rpb25UeXBlc1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vYWN0aW9ucy9hY3Rpb25UeXBlcy5qcyIsImltcG9ydCBhY3Rpb25UeXBlcyBmcm9tICcuL2FjdGlvblR5cGVzJ1xuaW1wb3J0IHsgY29tYmluZVJlZHVjZXJzIH0gZnJvbSAncmVkdXgnXG5cbmV4cG9ydCBjb25zdCBjcmVhdGVQYWdpbmF0b3IgPSAoZW5kcG9pbnQsIHJlc3VsdEtleSkgPT4ge1xuICAvLyBhY3Rpb25cbiAgY29uc3QgcmVxdWVzdFBhZ2UgPSAoZW5kcG9pbnQsIHJlc3VsdEtleSwgcGFnZSkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICB0eXBlOiBhY3Rpb25UeXBlcy5SRVFVRVNUX1BBR0UsXG4gICAgICBwYXlsb2FkOiB7XG4gICAgICAgIHBhZ2VcbiAgICAgIH0sXG4gICAgICBtZXRhOiB7XG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICByZXN1bHRLZXlcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBhY3Rpb25cbiAgY29uc3QgcmVjZWl2ZVBhZ2UgPSAocmVzdWx0S2V5LCBwYWdlLCByZXN1bHRzKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHR5cGU6IGFjdGlvblR5cGVzLlJFQ0VJVkVfUEFHRSxcbiAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgcGFnZSxcbiAgICAgICAgcmVzdWx0c1xuICAgICAgfSxcbiAgICAgIG1ldGE6IHtcbiAgICAgICAgcmVzdWx0S2V5XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC8vIFJlZHVjZXJcbiAgY29uc3QgcGFnZXMgPSAocGFnZXMgPSB7fSwgYWN0aW9uID0ge30pID0+IHtcbiAgICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgICBjYXNlIGFjdGlvblR5cGVzLlJFUVVFU1RfUEFHRTpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5wYWdlcyxcbiAgICAgICAgICBbYWN0aW9uLm1ldGEucmVzdWx0S2V5XToge1xuICAgICAgICAgICAgW2FjdGlvbi5wYXlsb2FkLnBhZ2VdOiB7XG4gICAgICAgICAgICAgIGlkczogW10sXG4gICAgICAgICAgICAgIGZldGNoaW5nOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBjYXNlIGFjdGlvblR5cGVzLlJFQ0VJVkVfUEFHRTpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5wYWdlcyxcbiAgICAgICAgICBbcmVzdWx0S2V5XToge1xuICAgICAgICAgICAgW2FjdGlvbi5wYXlsb2FkLnBhZ2VdOiB7XG4gICAgICAgICAgICAgIGlkczogYWN0aW9uLnBheWxvYWQucmVzdWx0cy5tYXAoc3RvcmUgPT4gc3RvcmUuX2lkKSxcbiAgICAgICAgICAgICAgZmV0Y2hpbmc6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gcGFnZXNcbiAgICB9XG4gIH1cblxuICAvLyBSZWR1Y2VyXG4gIGNvbnN0IGN1cnJlbnRQYWdlID0gKGN1cnJlbnRQYWdlID0gMSwgYWN0aW9uID0ge30pID0+XG4gICAgKGFjdGlvbi50eXBlID09PSBhY3Rpb25UeXBlcy5SRVFVRVNUX1BBR0VcbiAgICAgID8gYWN0aW9uLnBheWxvYWQucGFnZVxuICAgICAgOiBjdXJyZW50UGFnZSlcblxuICBjb25zdCBvbmx5Rm9yRW5kcG9pbnQgPSByZWR1Y2VyID0+IChzdGF0ZSA9IHt9LCBhY3Rpb24gPSB7fSkgPT4ge1xuICAgIGlmICh0eXBlb2YgYWN0aW9uLm1ldGEgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICByZXR1cm4gc3RhdGVcbiAgICB9XG4gICAgaWYgKGFjdGlvbi5tZXRhLmVuZHBvaW50ID09PSBlbmRwb2ludCkge1xuICAgICAgcmV0dXJuIHJlZHVjZXIoc3RhdGUsIGFjdGlvbilcbiAgICB9XG5cbiAgICBpZiAoYWN0aW9uLm1ldGEucmVzdWx0S2V5ID09PSByZXN1bHRLZXkpIHtcbiAgICAgIHJldHVybiByZWR1Y2VyKHN0YXRlLCBhY3Rpb24pXG4gICAgfVxuXG4gICAgcmV0dXJuIHN0YXRlXG5cbiAgICAvLyAodHlwZW9mIGFjdGlvbi5tZXRhID09PSAndW5kZWZpbmVkJ1xuICAgIC8vICAgPyBzdGF0ZVxuICAgIC8vICAgOiBhY3Rpb24ubWV0YS5lbmRwb2ludCA9PT0gZW5kcG9pbnQgPyByZWR1Y2VyKHN0YXRlLCBhY3Rpb24pIDogc3RhdGUpXG4gIH1cblxuICBjb25zdCBpdGVtc1JlZHVjZXIgPSAoaXRlbXMgPSB7fSwgYWN0aW9uID0ge30pID0+IHtcbiAgICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgICBjYXNlIGFjdGlvblR5cGVzLlJFQ0VJVkVfUEFHRTpcbiAgICAgICAgbGV0IF9pdGVtcyA9IHt9XG4gICAgICAgIGZvciAobGV0IGl0ZW0gb2YgYWN0aW9uLnBheWxvYWQucmVzdWx0cykge1xuICAgICAgICAgIF9pdGVtcyA9IHtcbiAgICAgICAgICAgIC4uLl9pdGVtcyxcbiAgICAgICAgICAgIFtpdGVtLl9pZF06IGl0ZW1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5pdGVtcyxcbiAgICAgICAgICAuLi5faXRlbXNcbiAgICAgICAgfVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIGl0ZW1zXG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVkdWNlciA9IG9ubHlGb3JFbmRwb2ludChcbiAgICBjb21iaW5lUmVkdWNlcnMoe1xuICAgICAgcGFnZXMsXG4gICAgICBjdXJyZW50UGFnZVxuICAgIH0pXG4gIClcblxuICByZXR1cm4ge1xuICAgIHJlcXVlc3RQYWdlLFxuICAgIHJlY2VpdmVQYWdlLFxuICAgIHJlZHVjZXIsXG4gICAgaXRlbXNSZWR1Y2VyOiBvbmx5Rm9yRW5kcG9pbnQoaXRlbXNSZWR1Y2VyKVxuICB9XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9hY3Rpb25zL3BhZ2luYXRvci5qcyIsImltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnXG5pbXBvcnQgZW52IGZyb20gJy4uL2NvbmZpZy9lbnZDb25maWcnXG5cbmNsYXNzIGF1dGhBcGkge1xuICBzdGF0aWMgYXN5bmMgc2lnbkluVXNlciAodXNlcikge1xuICAgIGNvbnN0IHVybCA9IGAke2Vudi5CQUNLRU5EX1VSTH0vYXBpL3NpZ25pbmBcbiAgICByZXR1cm4gZmV0Y2godXJsLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgICAgfSxcbiAgICAgIC8vIG1vZGU6ICdjb3JzJyxcbiAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZScsIC8vIERvbid0IGZvcmdldCB0byBzcGVjaWZ5IHRoaXMgaWYgeW91IG5lZWQgY29va2llc1xuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICB9KVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIHNpZ25PdXRVc2VyICgpIHtcbiAgICBjb25zdCB1cmwgPSBgJHtlbnYuQkFDS0VORF9VUkx9L2FwaS9zaWdub3V0YFxuICAgIHJldHVybiBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIH0sXG4gICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnXG4gICAgfSlcbiAgfVxuXG4gIHN0YXRpYyBhc3luYyByZWdpc3RlclVzZXIgKHVzZXIpIHtcbiAgICBjb25zdCB1cmwgPSBgJHtlbnYuQkFDS0VORF9VUkx9L2FwaS9yZWdpc3RlcmBcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIH0sXG4gICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnLCAvLyBEb24ndCBmb3JnZXQgdG8gc3BlY2lmeSB0aGlzIGlmIHlvdSBuZWVkIGNvb2tpZXNcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgfSlcblxuICAgIHJldHVybiByZXNwb25zZVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIGZldGNoUmVmcmVzaFRva2VucyAoKSB7XG4gICAgY29uc3QgdXJsID0gYCR7ZW52LkJBQ0tFTkRfVVJMfS9hcGkvcmVmcmVzaGBcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGNyZWRlbnRpYWxzOiAnaW5jbHVkZSdcbiAgICB9KVxuXG4gICAgcmV0dXJuIHJlc3BvbnNlXG4gIH1cblxuICBzdGF0aWMgYXN5bmMgdXBkYXRlVXNlciAodXNlcikge1xuICAgIGNvbnN0IHVybCA9IGAke2Vudi5CQUNLRU5EX1VSTH0vYXBpL2FjY291bnRgXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXG4gICAgICB9LFxuICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgfSlcblxuICAgIHJldHVybiByZXNwb25zZVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIGZvcmdvdFVzZXIgKGVtYWlsKSB7XG4gICAgY29uc3QgdXJsID0gYCR7ZW52LkJBQ0tFTkRfVVJMfS9hcGkvYWNjb3VudC9mb3Jnb3RgXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXG4gICAgICB9LFxuICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGVtYWlsKVxuICAgIH0pXG5cbiAgICByZXR1cm4gcmVzcG9uc2VcbiAgfVxuXG4gIHN0YXRpYyBhc3luYyByZXNldFBhc3N3b3JkIChwYXNzd29yZFRva2VuKSB7XG4gICAgY29uc3QgdXJsID0gYCR7ZW52LkJBQ0tFTkRfVVJMfS9hcGkvYWNjb3VudC9yZXNldGBcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIH0sXG4gICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocGFzc3dvcmRUb2tlbilcbiAgICB9KVxuXG4gICAgcmV0dXJuIHJlc3BvbnNlXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgYXV0aEFwaVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vYXBpL2F1dGhBcGkuanMiLCJpbXBvcnQgeyBnZXRVc2VyRnJvbUpXVCB9IGZyb20gJy4uL3V0aWxzL2F1dGhVdGlscydcbmltcG9ydCB7XG4gIGhhbmRsZU1pZGRsZXdhcmVFcnJvcixcbiAgaGFuZGxlU3RhdHVzQ2hlY2tcbn0gZnJvbSAnLi4vdXRpbHMvZXJyb3JIYW5kbGVycydcbmltcG9ydCBhY3Rpb25UeXBlcyBmcm9tICcuLi9hY3Rpb25zL2FjdGlvblR5cGVzJ1xuXG4vLyBUZXN0aW5nXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBkaXNwYXRjaCB9KSB7XG4gIHJldHVybiBuZXh0ID0+IGFzeW5jIGFjdGlvbiA9PiB7XG4gICAgLy8gY29uc29sZS5sb2coJ01pZGRsZXdhcmUnKVxuICAgIC8vIGNvbnNvbGUubG9nKCdhY3Rpb24nKVxuICAgIC8vIGNvbnNvbGUubG9nKGFjdGlvbi50eXBlKVxuXG4gICAgLyoqXG4gICAgICogLSBJZiBhY3Rpb24gb2JqZWN0IGRvZXMgbm90IGhhdmUga2V5IFwicGF5bG9hZFwiXG4gICAgICogLSBPciB0aGUgcGF5bG9hZCBpcyBub3QgYSBwcm9taXNlXG4gICAgICogLSBJZ25vcmUgYXBpSW50ZXJjZXB0b3JcbiAgICAgKlxuICAgICAqL1xuICAgIGlmICghYWN0aW9uLnBheWxvYWQgfHwgIWFjdGlvbi5wYXlsb2FkLnRoZW4pIHtcbiAgICAgIHJldHVybiBuZXh0KGFjdGlvbilcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhY3Rpb24ucGF5bG9hZFxuXG4gICAgICAvLyBERUJVR1xuICAgICAgLy8gY29uc29sZS5sb2coJ2VzNiBhd2FpdCBwcm9taXNlIGluIG1pZGRsZXdhcmUnKVxuICAgICAgLy8gY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UsIG51bGwsIDIpKVxuICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2Uuc3RhdHVzKVxuICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2Uuc3RhdHVzVGV4dClcbiAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3BvbnNlLmhlYWRlcnMpXG5cbiAgICAgIGF3YWl0IGhhbmRsZVN0YXR1c0NoZWNrKHJlc3BvbnNlLCBkaXNwYXRjaCwgYWN0aW9uLnR5cGUpXG5cbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXNwb25zZS5qc29uKClcblxuICAgICAgLy8gY29uc29sZS5sb2coJ2JvZHkgZnJvbSBtaWRkbGV3YXJlJylcbiAgICAgIC8vIGNvbnNvbGUubG9nKGJvZHkpXG4gICAgICAvLyBjb25zb2xlLmxvZygnYWN0aW9uIHR5cGUnKVxuICAgICAgLy8gY29uc29sZS5sb2coYWN0aW9uLnR5cGUpXG5cbiAgICAgIGlmIChib2R5LnRva2VuICYmIGFjdGlvbi50eXBlID09PSAnTE9HX1VTRVJfSU4nKSB7XG4gICAgICAgIC8vIEN1cnJlbnRseSB0aGlzIGFjdGlvbiBoYXMgbm8gcmVkdWNlclxuICAgICAgICBjb25zdCBuZXdBY3Rpb24gPSB7XG4gICAgICAgICAgdHlwZTogYWN0aW9uLnR5cGUsXG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgdG9rZW46IGJvZHkudG9rZW4sXG4gICAgICAgICAgICBoZWFydHM6IGJvZHkuaGVhcnRzXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gU2VuZCB0aHJvdWdoIGFsbCB0aGUgbWlkZGxld2FyZXMgYWdhaW5cbiAgICAgICAgZGlzcGF0Y2gobmV3QWN0aW9uKVxuXG4gICAgICAgIC8vIE1PRElGWSBDUkVBVEUgVE8gRE8gVEhFIFNBTUUgVEhJTkcgV0lUSCBIRUFSVFNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0b2tlbjogYm9keS50b2tlbixcbiAgICAgICAgICBoZWFydHM6IGJvZHkuaGVhcnRzXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGJvZHkudG9rZW4gJiYgYWN0aW9uLnR5cGUgPT09ICdDUkVBVEVfVVNFUicpIHtcbiAgICAgICAgY29uc3QgbmV3QWN0aW9uID0ge1xuICAgICAgICAgIHR5cGU6IGFjdGlvbi50eXBlLFxuICAgICAgICAgIGRhdGE6IGJvZHkudG9rZW5cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNlbmQgdGhyb3VnaCBhbGwgdGhlIG1pZGRsZXdhcmVzIGFnYWluXG4gICAgICAgIGRpc3BhdGNoKG5ld0FjdGlvbilcbiAgICAgICAgcmV0dXJuIGJvZHkudG9rZW5cbiAgICAgIH1cblxuICAgICAgaWYgKGJvZHkudG9rZW4gJiYgYWN0aW9uLnR5cGUgIT09ICdMT0dfT1VUJykge1xuICAgICAgICBjb25zb2xlLmxvZygnYm9keSBoYXMgdG9rZW4gaW4gaXQnKVxuICAgICAgICBjb25zb2xlLmxvZygnc2F2ZSBuZXcgdXNlciB0byByZWR1eCcpXG5cbiAgICAgICAgY29uc3QgZGVjb2RlZFVzZXIgPSBnZXRVc2VyRnJvbUpXVChib2R5LnRva2VuKVxuXG4gICAgICAgIGRpc3BhdGNoKHtcbiAgICAgICAgICB0eXBlOiBhY3Rpb25UeXBlcy5SRUZSRVNIX1RPS0VOLFxuICAgICAgICAgIHVzZXI6IHsgLi4uZGVjb2RlZFVzZXIgfVxuICAgICAgICB9KVxuICAgICAgfVxuXG4gICAgICBjb25zdCBuZXdBY3Rpb24gPSB7XG4gICAgICAgIHR5cGU6IGFjdGlvbi50eXBlLFxuICAgICAgICBkYXRhOiBib2R5LmRhdGFcbiAgICAgIH1cblxuICAgICAgLy8gY29uc29sZS5sb2coJ25ldyBhY3Rpb24nKVxuICAgICAgLy8gY29uc29sZS5sb2cobmV3QWN0aW9uKVxuXG4gICAgICAvLyBTZW5kIHRocm91Z2ggYWxsIHRoZSBtaWRkbGV3YXJlcyBhZ2FpblxuICAgICAgZGlzcGF0Y2gobmV3QWN0aW9uKVxuICAgICAgcmV0dXJuIGJvZHkuZGF0YVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdtaWRkbGV3YXJlIGVycm9yJylcbiAgICAgIGhhbmRsZU1pZGRsZXdhcmVFcnJvcihlLCBkaXNwYXRjaClcbiAgICAgIHRocm93IGVcbiAgICB9XG4gIH1cbn1cblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL21pZGRsZXdhcmUvYXBpSW50ZXJjZXB0ZXIuanMiLCJpbXBvcnQgYWN0aW9uVHlwZXMgZnJvbSAnLi4vYWN0aW9ucy9hY3Rpb25UeXBlcydcbmltcG9ydCBpbml0aWFsU3RhdGUgZnJvbSAnLi9pbml0aWFsU3RhdGUnXG5cbmV4cG9ydCBjb25zdCBhdXRoUmVkdWNlciA9IChzdGF0ZSA9IGluaXRpYWxTdGF0ZS51c2VyLCBhY3Rpb24pID0+IHtcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgIC8vIGNhc2UgYWN0aW9uVHlwZXMuVE9HR0xFX0xPR0lOOlxuICAgIC8vICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHN0YXRlLCB7XG4gICAgLy8gICAgIGlzQXV0aGVudGljYXRlZDogIXN0YXRlLmlzQXV0aGVudGljYXRlZFxuICAgIC8vICAgfSlcbiAgICBjYXNlIGFjdGlvblR5cGVzLlNBVkVfVVNFUjpcbiAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBzdGF0ZSwge1xuICAgICAgICAuLi5hY3Rpb24udXNlcixcbiAgICAgICAgaXNBdXRoZW50aWNhdGVkOiB0cnVlXG4gICAgICB9KVxuICAgIGNhc2UgYWN0aW9uVHlwZXMuUkVGUkVTSF9UT0tFTjpcbiAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBzdGF0ZSwge1xuICAgICAgICAuLi5hY3Rpb24udXNlcixcbiAgICAgICAgaXNBdXRoZW50aWNhdGVkOiB0cnVlXG4gICAgICB9KVxuICAgIGNhc2UgYWN0aW9uVHlwZXMuTE9HX09VVDpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlzQXV0aGVudGljYXRlZDogZmFsc2VcbiAgICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHN0YXRlXG4gIH1cbn1cblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuL3JlZHVjZXJzL2F1dGhSZWR1Y2VyLmpzIiwiaW1wb3J0IGFjdGlvblR5cGVzIGZyb20gJy4uL2FjdGlvbnMvYWN0aW9uVHlwZXMnXG5pbXBvcnQgaW5pdGlhbFN0YXRlIGZyb20gJy4vaW5pdGlhbFN0YXRlJ1xuXG5leHBvcnQgY29uc3QgZWRpdEFjY291bnRSZWR1Y2VyID0gKFxuICBzdGF0ZSA9IGluaXRpYWxTdGF0ZS51c2VyQWNjb3VudCxcbiAgYWN0aW9uXG4pID0+IHtcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgIGNhc2UgYWN0aW9uVHlwZXMuTE9BRF9VU0VSX0RBVEE6XG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUsIHtcbiAgICAgICAgZGF0YTogYWN0aW9uLnVzZXJcbiAgICAgIH0pXG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBzdGF0ZVxuICB9XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9yZWR1Y2Vycy9lZGl0QWNjb3VudFJlZHVjZXIuanMiLCJpbXBvcnQgYWN0aW9uVHlwZXMgZnJvbSAnLi4vYWN0aW9ucy9hY3Rpb25UeXBlcydcbi8vIGltcG9ydCBpbml0aWFsU3RhdGUgZnJvbSAnLi9pbml0aWFsU3RhdGUnXG5pbXBvcnQgeyBjcmVhdGVQYWdpbmF0b3IgfSBmcm9tICcuLi9hY3Rpb25zL3BhZ2luYXRvcidcbi8vIERhdGEgc2hhcGUgLSBSRUNJRVZFIFNUT1JFIFBBR0Vcbi8vIHBhZ2luYXRpb246IHtcbi8vICAgICBwYWdlczoge1xuLy8gICAgICAgMToge1xuLy8gICAgICAgICBpZHM6IFsgJ3RvZG8xJywgJ3RvZG8yJyBdLFxuLy8gICAgICAgICBmZXRjaGluZzogZmFsc2Vcbi8vICAgICAgIH0sXG4vLyAgICAgfVxuLy8gfVxuXG5leHBvcnQgY29uc3QgcGFnaW5hdGlvbiA9IGNyZWF0ZVBhZ2luYXRvcignL3N0b3JlcycsICdzdG9yZXMnKVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vcmVkdWNlcnMvcGFnZVJlZHVjZXIuanMiLCJpbXBvcnQgaW5pdGlhbFN0YXRlIGZyb20gJy4vaW5pdGlhbFN0YXRlJ1xuZXhwb3J0IGNvbnN0IHRpbWVSZWR1Y2VyID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLnRpbWUsIGFjdGlvbikgPT4ge1xuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgY2FzZSAnVElDSyc6XG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUsIGFjdGlvbi50b2tlblRpbWUpXG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBzdGF0ZVxuICB9XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9yZWR1Y2Vycy90aW1lUmVkdWNlci5qcyIsImltcG9ydCB7IGNyZWF0ZVN0b3JlLCBhcHBseU1pZGRsZXdhcmUsIGNvbWJpbmVSZWR1Y2VycyB9IGZyb20gJ3JlZHV4J1xuaW1wb3J0IHRodW5rTWlkZGxld2FyZSBmcm9tICdyZWR1eC10aHVuaydcbmltcG9ydCB7IGNvbXBvc2VXaXRoRGV2VG9vbHMgfSBmcm9tICdyZWR1eC1kZXZ0b29scy1leHRlbnNpb24nXG5pbXBvcnQgeyByZWR1Y2VyIGFzIGZvcm1SZWR1Y2VyIH0gZnJvbSAncmVkdXgtZm9ybSdcbmltcG9ydCB7IGF1dGhSZWR1Y2VyIH0gZnJvbSAnLi9yZWR1Y2Vycy9hdXRoUmVkdWNlcidcbmltcG9ydCB7IHRpbWVSZWR1Y2VyIH0gZnJvbSAnLi9yZWR1Y2Vycy90aW1lUmVkdWNlcidcbmltcG9ydCB7IHJlZHVjZXIgYXMgdG9hc3RyUmVkdWNlciB9IGZyb20gJ3JlYWN0LXJlZHV4LXRvYXN0cidcbmltcG9ydCB7IGVkaXRBY2NvdW50UmVkdWNlciB9IGZyb20gJy4vcmVkdWNlcnMvZWRpdEFjY291bnRSZWR1Y2VyJ1xuaW1wb3J0IGFwaUludGVyY2VwdGVyIGZyb20gJy4vbWlkZGxld2FyZS9hcGlJbnRlcmNlcHRlcidcbmltcG9ydCB7IHBhZ2luYXRpb24gfSBmcm9tICcuL3JlZHVjZXJzL3BhZ2VSZWR1Y2VyJ1xuXG5leHBvcnQgY29uc3QgaW5pdFN0b3JlID0gKGluaXRpYWxTdGF0ZSA9IHt9KSA9PiB7XG4gIC8vIG1pcnJvciBvZiBzdGF0ZSBmcm9tIG9yaWdpbmFsIGFwcFxuICBjb25zdCByZWR1Y2VycyA9IGNvbWJpbmVSZWR1Y2Vycyh7XG4gICAgdXNlcjogYXV0aFJlZHVjZXIsXG4gICAgZm9ybTogZm9ybVJlZHVjZXIsXG4gICAgdXNlckFjY291bnQ6IGVkaXRBY2NvdW50UmVkdWNlcixcbiAgICB0b2FzdHI6IHRvYXN0clJlZHVjZXIsXG4gICAgdGltZTogdGltZVJlZHVjZXIsXG4gICAgcGFnaW5hdGlvbjogcGFnaW5hdGlvbi5yZWR1Y2VyXG4gIH0pXG5cbiAgbGV0IGVudiA9IHByb2Nlc3MuZW52Lk5PREVfRU5WIHx8ICdkZXZlbG9wbWVudCdcblxuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgZW52ID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgcmV0dXJuIGNyZWF0ZVN0b3JlKFxuICAgICAgcmVkdWNlcnMsXG4gICAgICBpbml0aWFsU3RhdGUsXG4gICAgICBjb21wb3NlV2l0aERldlRvb2xzKGFwcGx5TWlkZGxld2FyZSh0aHVua01pZGRsZXdhcmUsIGFwaUludGVyY2VwdGVyKSlcbiAgICApXG4gIH1cblxuICByZXR1cm4gY3JlYXRlU3RvcmUoXG4gICAgcmVkdWNlcnMsXG4gICAgaW5pdGlhbFN0YXRlLFxuICAgIGFwcGx5TWlkZGxld2FyZSh0aHVua01pZGRsZXdhcmUsIGFwaUludGVyY2VwdGVyKVxuICApXG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9zdG9yZS5qcyIsIi8vIEBmbG93XG5cbmltcG9ydCBqd3REZWNvZGUgZnJvbSAnand0LWRlY29kZSdcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xuaW1wb3J0IHtcbiAgbG9nVXNlck91dCxcbiAgcmVmcmVzaFRva2VuQWN0aW9uLFxuICBsb2dPdXQsXG4gIHNhdmVVc2VyVG9SZWR1eFxufSBmcm9tICcuLi9hY3Rpb25zL2F1dGhBY3Rpb25zJ1xuaW1wb3J0IHR5cGUgeyBVc2VyIH0gZnJvbSAnLi4vZmxvd1R5cGVzL1VzZXInXG5pbXBvcnQgdHlwZSB7IFJlZHV4U3RvcmUgfSBmcm9tICcuLi9mbG93VHlwZXMvcmVkdXhTdG9yZSdcbmltcG9ydCB0eXBlIHsgQWN0aW9uIH0gZnJvbSAnLi4vZmxvd1R5cGVzL3JlZHV4J1xuXG50eXBlIHZvaWRTdHJpbmcgPSBzdHJpbmcgfCB2b2lkXG50eXBlIHZvaWRTdHJpbmdBcnJheSA9IHN0cmluZ1tdIHwgdm9pZFxudHlwZSBzZXJ2ZXJDb29raWVzID0gc3RyaW5nW10gfCB2b2lkXG4vKipcbiAqIHVuc2V0VG9rZW4oKVxuICogLSBBZGRzIGxvZ291dCB0aW1lc3RhbXAgdG8gbG9jYWxzdG9yYWdlIHRvIHRyaWdnZXIgZXZlbnQgYWNjcm9zcyB0YWJzXG4gKlxuICovXG5leHBvcnQgY29uc3QgdW5zZXRUb2tlbiA9ICgpID0+IHtcbiAgaWYgKCFwcm9jZXNzLmJyb3dzZXIpIHtcbiAgICByZXR1cm5cbiAgfVxuICAvLyB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3Rva2VuJylcbiAgLy8gd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd1c2VyJylcbiAgLy8gQ29va2llLnJlbW92ZSgnand0JylcblxuICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2xvZ291dCcsIERhdGUubm93KCkpXG59XG5jb25zdCBzdHJpbmdTcGxpdCA9IChqd3RUb2tlbjogc3RyaW5nIHwgdm9pZCwgc3BsaXR0ZXI6IHN0cmluZyk6IHZvaWRTdHJpbmcgPT4ge1xuICBpZiAoIWp3dFRva2VuKSByZXR1cm4gdW5kZWZpbmVkXG4gIHJldHVybiBqd3RUb2tlblxuICAgIC5zcGxpdChzcGxpdHRlcilbMV1cbn1cblxuY29uc3QgZmluZEtleSA9IChqd3RUb2tlbjogc3RyaW5nLCBrZXk6IHN0cmluZykgPT4ge1xuICBpZiAoIWp3dFRva2VuKSByZXR1cm4gdW5kZWZpbmVkXG4gIHJldHVybiBqd3RUb2tlbi5zcGxpdCgnOycpLmZpbmQoYyA9PiBjLnRyaW0oKS5zdGFydHNXaXRoKGAke2tleX09YCkpXG59XG5cbi8qKlxuICogZ2V0VG9rZW5Gcm9tQ29va2llKGFyZylcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdCAtIGZyb20gU2VydmVyLXNpZGVcbiAqIEByZXR1cm5zIHtPYmplY3R9IHVuZGVmaW5lZFxuICogQHJldHVybnMge3N0cmluZ30gand0LXRva2VuXG4gKi9cbmV4cG9ydCBjb25zdCBnZXRUb2tlbkZyb21Db29raWUgPSAocmVxdWVzdDogYW55KTogdm9pZFN0cmluZyA9PiB7XG4gIGlmICghcmVxdWVzdC5oZWFkZXJzLmNvb2tpZSkge1xuICAgIHJldHVybiB1bmRlZmluZWRcbiAgfVxuXG4gIGNvbnN0IGp3dENvb2tpZTogc3RyaW5nID0gcmVxdWVzdC5oZWFkZXJzLmNvb2tpZVxuICByZXR1cm4gc3RyaW5nU3BsaXQoZmluZEtleShqd3RDb29raWUsICdqd3QnKSwgJz0nKVxufVxuXG4vKipcbiAqIGdldFRva2VuRnJvbUNvb2tpZVJlcyhhcmcpIC0gdXNlZCBzcGVjaWZpY2FsbHkgZm9yIFJFU1BPTlNFIGNvb2tpZXMgb24gU1NSIG5leHQuanNcbiAqXG4gKiBAcGFyYW0ge0FycmF5fSBjb29raWVzIC0gZnJvbSBTZXJ2ZXItc2lkZVxuICogQHJldHVybnMge3N0cmluZ30gand0LXRva2VuIHx8IHVuZGVmaW5lZFxuICovXG5leHBvcnQgY29uc3QgZ2V0VG9rZW5Gcm9tQ29va2llUmVzID0gKGNvb2tpZXM6IHNlcnZlckNvb2tpZXMpOiB2b2lkU3RyaW5nID0+IHtcbiAgY29uc29sZS5sb2coJ2ZpbmQgZXJyb3InKVxuICBjb25zb2xlLmxvZyhjb29raWVzKVxuXG4gIGlmICghY29va2llcykge1xuICAgIHJldHVybiB1bmRlZmluZWRcbiAgfVxuICBjb25zb2xlLmxvZygnc3RlcDEnKVxuXG4gIGNvbnNvbGUubG9nKGNvb2tpZXNbMF0pXG4gIGNvbnNvbGUubG9nKCdzdGVwMicpXG5cbiAgcmV0dXJuIHN0cmluZ1NwbGl0KGZpbmRLZXkoY29va2llc1swXSwgJ2p3dCcpLCAnPScpXG59XG5cbi8qKlxuICogZ2V0Q29va2llc0Zyb21TZXJ2ZXJSZXNwb25zZShhcmcpXG4gKiAtIEhlbHBlciBoYWNrIHRvIGdldCBjb29raWVzIGZyb20gaGVhZGVycyBvbiBOZXh0LmpzIFNlcnZlciByZXNwb25zZVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBjdHhIZWFkZXJzIC0gZnJvbSBTZXJ2ZXItc2lkZVxuICogQHJldHVybnMge1N0cmluZ30gY29va2llc1xuICovXG5leHBvcnQgY29uc3QgZ2V0Q29va2llc0Zyb21TZXJ2ZXJSZXNwb25zZSA9IChjdHhIZWFkZXJzOiBhbnkpOiB2b2lkU3RyaW5nQXJyYXkgPT4ge1xuICBpZiAoIWN0eEhlYWRlcnMpIHJldHVybiB1bmRlZmluZWRcblxuICBjb25zdCByZXNDb29raWVzID0gY3R4SGVhZGVyc1snc2V0LWNvb2tpZSddXG4gIHJldHVybiByZXNDb29raWVzXG59XG5cbi8qKlxuICogZmluZFRva2VuVG9EZWNvZGUoaGVhZGVycywgcmVxKVxuICogLSBOZXh0LmpzIFNlcnZlci1zaWRlIGZ1bmMgdG8gZmlyc3QgbG9vayBmb3IgbmV3IHRva2VuIGJlaW5nIHNlbnQgZnJvbSBBUElcbiAqIC0gSWYgbm9uZSBpcyBmb3VuZCBvbiBSRVMsIHVzZSByZXEgaGVhZGVyc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBjdHhIZWFkZXJzIC0gZnJvbSBTZXJ2ZXItc2lkZVxuICogQHBhcmFtIHtPYmplY3R9IGN0eFJlcSAtIGZyb20gU2VydmVyLXNpZGVcbiAqIEByZXR1cm5zIHtTdHJpbmd9IENvb2tpZSBUb2tlblxuICovXG5leHBvcnQgY29uc3QgZmluZFRva2VuVG9EZWNvZGUgPSAoY3R4SGVhZGVyczogYW55LCBjdHhSZXE6IGFueSkgPT4ge1xuICBjb25zdCBjb29raWVzOiB2b2lkU3RyaW5nQXJyYXkgPSBnZXRDb29raWVzRnJvbVNlcnZlclJlc3BvbnNlKGN0eEhlYWRlcnMpXG5cbiAgaWYgKGNvb2tpZXMpIHtcbiAgICBjb25zb2xlLmxvZygnaGFzIG5ldyB1c2VyJylcbiAgICByZXR1cm4gZ2V0VG9rZW5Gcm9tQ29va2llUmVzKGNvb2tpZXMpXG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coJ25vIG5ldyB1c2VyLCB1c2Ugb3JpZ2luYWwgdG9rZW4gaWYgdGhlcmUgaXMgb25lJylcbiAgICByZXR1cm4gZ2V0VG9rZW5Gcm9tQ29va2llKGN0eFJlcSlcbiAgfVxufVxuXG4vKipcbiAqIGNvbnZlcnRSZXNDb29raWVzVG9TdHJpbmcoY29va2llcylcbiAqIC0gTmV4dC5qcyBTZXJ2ZXItc2lkZSBmdW5jIHRvIGNvbnZlcnQgQ29va2llIGZyb20gUmVzcG9uc2UgQVBJXG4gKlxuICogQHBhcmFtIHtBcnJheX0gY29va2llcyAtIGZyb20gU2VydmVyLXNpZGVcbiAqIEByZXR1cm5zIHtTdHJpbmd9IENvb2tpZSBUb2tlblxuICovXG5leHBvcnQgY29uc3QgY29udmVydFJlc0Nvb2tpZXNUb1N0cmluZyA9IChjb29raWVzOiBhbnkpOiBzdHJpbmcgPT4ge1xuICBjb25zdCBjb29raWVzQXJyYXk6IHN0cmluZ1tdID0gW11cblxuICBjb25zdCBqd3RTdHJpbmc6IHZvaWRTdHJpbmcgPSBzdHJpbmdTcGxpdChmaW5kS2V5KGNvb2tpZXNbMF0sICdqd3QnKSwgJz0nKVxuICBjb25zdCBqd3QgPSAnand0PScgKyBTdHJpbmcoand0U3RyaW5nKVxuXG4gIGNvbnN0IGNzcmZTdHJpbmc6IHZvaWRTdHJpbmcgPSBzdHJpbmdTcGxpdChmaW5kS2V5KGNvb2tpZXNbMV0sICdfQ1NSRicpLCAnPScpXG4gIGNvbnN0IGNzcmYgPSAnX0NTUkY9JyArIFN0cmluZyhjc3JmU3RyaW5nKVxuXG4gIGNvb2tpZXNBcnJheS5wdXNoKGp3dCwgY3NyZilcbiAgcmV0dXJuIGNvb2tpZXNBcnJheS50b1N0cmluZygpLnJlcGxhY2UoJywnLCAnOyAnKVxufVxuXG4vKipcbiAqIGZpbmRDb29raWVzKGN0eEhlYWRlcnMsIGN0eFJlcSlcbiAqIC0gTmV4dC5qcyBTZXJ2ZXItc2lkZSBmdW5jIHRvIGZpcnN0IGxvb2sgZm9yIG5ldyB0b2tlbiBiZWluZyBzZW50IGZyb20gQVBJXG4gKiAtIFRoaXMgaGVscHMgdGhlIFZhbGlkYXRlIFNlcnZlciBUb2tlbiBmdW5jdGlvbiBsb29raW5nIGZvciBjb29raWVzIHNlcnZlci1zaWRlXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGN0eEhlYWRlcnMgLSBmcm9tIFNlcnZlci1zaWRlXG4gKiBAcGFyYW0ge09iamVjdH0gY3R4UmVxIC0gZnJvbSBTZXJ2ZXItc2lkZVxuICogQHJldHVybnMge1N0cmluZ30gSldUIC0gVG9rZW5cbiAqL1xuZXhwb3J0IGNvbnN0IGZpbmRDb29raWVzID0gKGN0eEhlYWRlcnM6IGFueSwgY3R4UmVxOiBhbnkpOiB2b2lkU3RyaW5nID0+IHtcbiAgaWYgKCFjdHhSZXEpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkXG4gIH1cblxuICBpZiAoIWN0eEhlYWRlcnMpIHtcbiAgICByZXR1cm4gY3R4UmVxLmhlYWRlcnMuY29va2llXG4gIH1cblxuICBjb25zdCBjb29raWVzOiB2b2lkU3RyaW5nQXJyYXkgPSBnZXRDb29raWVzRnJvbVNlcnZlclJlc3BvbnNlKGN0eEhlYWRlcnMpXG5cbiAgaWYgKGNvb2tpZXMpIHtcbiAgICBjb25zb2xlLmxvZygnaGFzIG5ldyBjb29raWVzJylcbiAgICByZXR1cm4gY29udmVydFJlc0Nvb2tpZXNUb1N0cmluZyhjb29raWVzKVxuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKCd1c2Ugb2xkIGNvb2tpZXMnKVxuICAgIHJldHVybiBjdHhSZXEuaGVhZGVycy5jb29raWVcbiAgfVxufVxuXG4vKipcbiAqIGdldFVzZXJGcm9tSldUKGFyZylcbiAqIC0gRmlsdGVyIG91dCBzZW5zaXRpdmUgaW5mbyB3aGVuIHRoZSB0b2tlbiBpcyBkZWNvZGVkIGJlZm9yZSBhZGRpbmcgdG8gcmVkdXhcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gdG9rZW5cbiAqIEByZXR1cm5zIHtPYmplY3R9XG4gKlxuICovXG5leHBvcnQgY29uc3QgZ2V0VXNlckZyb21KV1QgPSAodG9rZW46IHN0cmluZykgPT4ge1xuICBpZiAoIXRva2VuKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZFxuICB9XG5cbiAgY29uc3QgdG9rZW5EZWNvZGVkOiBVc2VyID0gand0RGVjb2RlKHRva2VuKVxuICAvLyBXb3VsZCB3YW50IHRvIGFsbG93IG1ldGFEYXRhIGhlcmVcbiAgY29uc3QgYWxsb3dlZEtleXMgPSBbJ25hbWUnLCAnZW1haWwnLCAnZXhwJywgJ3N1YiddXG5cbiAgcmV0dXJuIE9iamVjdC5rZXlzKHRva2VuRGVjb2RlZClcbiAgICAuZmlsdGVyKChrZXkpID0+IGFsbG93ZWRLZXlzLmluY2x1ZGVzKGtleSkpXG4gICAgLnJlZHVjZSgob2JqLCBrZXkpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLm9iaixcbiAgICAgICAgW2tleV06IHRva2VuRGVjb2RlZFtrZXldXG4gICAgICB9XG4gICAgfSwge30pXG5cbiAgLy8gcmV0dXJuIGp3dERlY29kZSh0b2tlbilcbn1cblxuLyoqXG4gKiBpc1VzZXJFeHBpcmVkKHVzZXIpXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHVzZXJcbiAqIEByZXR1cm5zIHtCb29sZWFufVxuICpcbiAqL1xuZXhwb3J0IGNvbnN0IGlzVXNlckV4cGlyZWQgPSAodXNlcjogVXNlcik6IGJvb2xlYW4gPT4ge1xuICBpZiAodXNlci5leHApIHtcbiAgICBjb25zdCBjdXJyZW50VGltZTogc3RyaW5nID0gbW9tZW50KCkudW5peCgpXG4gICAgY29uc3QgZXhwaXJlZDogYm9vbGVhbiA9IHVzZXIuZXhwIDwgY3VycmVudFRpbWUgLy8gYmVjYXVzZSB0aW1lIGdvZXMgdXBcblxuICAgIGlmIChleHBpcmVkKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmYWxzZVxufVxuXG4vKipcbiAqIHZhbGlkYXRlVXNlclRva2VuQ2xpZW50KHN0b3JlLCB1c2VyKVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBzdG9yZVxuICogQHBhcmFtIHtPYmplY3R9IHVzZXJcbiAqIEByZXR1cm5zIHtPYmplY3R9IHtEaXNwYXRjaCBBY3Rpb246IGxvZ091dH1cbiAqIEByZXR1cm5zIHtPYmplY3R9IHtEaXNwYXRjaCBBY3Rpb246IGxvZ1VzZXJPdXR9XG4gKiBAcmV0dXJucyB7T2JqZWN0fSB7RGlzcGF0Y2ggQWN0aW9uOiByZWZyZXNoVG9rZW59XG4gKiBAcmV0dXJucyB7T2JqZWN0fSB7RGlzcGF0Y2ggQWN0aW9uOiBzYXZlVXNlclRvUmVkdXh9XG4gKi9cbmV4cG9ydCBjb25zdCB2YWxpZGF0ZVVzZXJUb2tlbkNsaWVudCA9IGFzeW5jIChzdG9yZTogUmVkdXhTdG9yZSwgdXNlcjogVXNlcik6IEFjdGlvbiA9PiB7XG4gIGNvbnNvbGUubG9nKCd2YWxpZGF0ZVVzZXItQ2xpZW50JylcbiAgaWYgKCF1c2VyKSB7XG4gICAgcmV0dXJuIHN0b3JlLmRpc3BhdGNoKGxvZ1VzZXJPdXQoKSlcbiAgfVxuXG4gIC8vIGlmIGV4cGlyZWQgbG9nIHVzZXIgb3V0XG4gIGlmIChpc1VzZXJFeHBpcmVkKHVzZXIpKSB7XG4gICAgY29uc29sZS5sb2coJ3VzZXIgaXMgZXhwaXJlZCcpXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCBzdG9yZS5kaXNwYXRjaChyZWZyZXNoVG9rZW5BY3Rpb24odXNlcikpXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coJ3JlZnJlc2ggdG9rZW4gZXJyb3InKVxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIHZhbGlkYXRlVXNlclRva2VuU2VydmVyKHN0b3JlLCB1c2VyLCBjb29raWUpXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHN0b3JlXG4gKiBAcGFyYW0ge09iamVjdH0gdXNlclxuICogQHBhcmFtIHtPYmplY3R9IGNvb2tpZXNcbiAqIEByZXR1cm5zIHtPYmplY3R9IHtEaXNwYXRjaCBBY3Rpb246IGxvZ091dH1cbiAqIEByZXR1cm5zIHtPYmplY3R9IHtEaXNwYXRjaCBBY3Rpb246IGxvZ1VzZXJPdXR9IChleHBpcmVkKVxuICogQHJldHVybnMge09iamVjdH0ge0Rpc3BhdGNoIEFjdGlvbjogc2F2ZVVzZXJUb1JlZHV4fVxuICovXG5leHBvcnQgY29uc3QgdmFsaWRhdGVVc2VyVG9rZW5TZXJ2ZXIgPSBhc3luYyAoc3RvcmU6IFJlZHV4U3RvcmUsIHVzZXI6IFVzZXIsIGNvb2tpZXM/OiBzdHJpbmcpOiBBY3Rpb24gPT4ge1xuICAvKlxuICAgKiBmaW5kIGNvb2tpZXMgb24gYnJvd3Nlcihqd3QpXG4gICAqIGZpbmQgdXNlciBmcm9tIHRva2VuIGFuZCBwYXNzIHVzZXIgaW4gdG8gdGhpcyBmdW5jdGlvbiBmcm9tIGdldEluaXRpYWxQcm9wcyBvbiBIT0NcbiAgICogLSBpZiB0aGVyZSBpcyBubyB1c2VyKHVuZGVmaW5lZCkgLSBkaXNwYXRjaCBsb2dvdXRcbiAgICogLSBpZiB0aGVyZSBpcyBhIG5ldyB1c2VyXG4gICAqIC0gcmV0dXJuIG5ldyB1c2VyIHRvIHNhdmUgdG8gcmVkdXhcbiAgICogLSByZXR1cm4gb2xkIHVzZXIgdG8gc2F2ZSB0byByZWR1eFxuICAgKi9cbiAgY29uc29sZS5sb2coJ3ZhbGlkYXRlVXNlci1TZXJ2ZXInLCB1c2VyKVxuXG4gIGlmICghdXNlcikge1xuICAgIHJldHVybiBzdG9yZS5kaXNwYXRjaChsb2dPdXQoKSlcbiAgfVxuXG4gIC8qXG4gICBTYXZlIHVzZXIgZnJvbSB0b2tlblxuICAgKi9cbiAgY29uc29sZS5sb2coJ3NhdmUgdXNlcicpXG5cbiAgLy8gZXhhbXBsZSBvZiBnZXR0aW5nIG1vcmUgVVNFUiBtZXRhIGRhdGFcbiAgLy8gVGhhbiB3aGF0IGlzIGp1c3QgZ2l2ZW4gdG8gdXMgZnJvbSB0aGUgSldUXG4gIC8vIGF3YWl0IHN0b3JlLmRpc3BhdGNoKGdldFVzZXJIZWFydHMoY29va2llcykpXG4gIHJldHVybiBzdG9yZS5kaXNwYXRjaChzYXZlVXNlclRvUmVkdXgodXNlcikpXG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi91dGlscy9hdXRoVXRpbHMuanMiLCJpbXBvcnQgeyB0b2FzdHIgfSBmcm9tICdyZWFjdC1yZWR1eC10b2FzdHInXG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJ1xuaW1wb3J0IHsgbG9nVXNlck91dCB9IGZyb20gJy4uL2FjdGlvbnMvYXV0aEFjdGlvbnMnXG4vKipcbiAqIGhhbmRsZU1pZGRsZXdhcmVFcnJvcihhcmcpIC1ERVBSSUNBVEVELVxuICogLSBUaGlzIGZ1bmN0aW9uIFNIT1VMRCBCRSB1cGRhdGVkIG9uY2Ugb2xkIGFzeW5jIGNhbGxzIGFyZSByb3V0ZWQgdGhyb3VnaCB0aGUgbWlkZGxld2FyZVxuICogLSBObyBsb2dvdXQgZXJycm9yIE9CSiB3aWxsIGJlIHNlbnQgb3V0IHNvIHVwZGF0ZSBhY2NvcmRpbmdseVxuICogLSBDdXJyZW50bHkgdGhpcyBpcyBpbiBzdG9yZUFQSS5qc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBlcnJvclxuICogQHBhcmFtIHtPYmplY3R9IHJlZHV4IGRpc3BhdGNoXG4gKi9cbmV4cG9ydCBjb25zdCBoYW5kbGVNaWRkbGV3YXJlRXJyb3IgPSBhc3luYyAoZSwgZGlzcGF0Y2gpID0+IHtcbiAgY29uc29sZS5sb2coJ2hhbmRsZUVycm9yIGZyb20gQXV0aFV0aWxzIHRvIGJlIFVQREFURUQgYW5kIEZJWEVEJylcbiAgY29uc29sZS5sb2coZSlcblxuICBpZiAoZS5sb2dvdXQpIHtcbiAgICB0b2FzdHIuZXJyb3IoJ0Vycm9yOicsIGUubWVzc2FnZSlcbiAgICAvLyBkaXNwYXRjaChsb2dVc2VyT3V0KCkpXG4gICAgY29uc29sZS5sb2coXG4gICAgICAnU0hPVUxEIExPRyBVU0VSIE9VUiwgQlVUIFNIT1VMRCBIQVBQRU4gV0lUSCBNSURETEVXQVJFIE5PVCBFUlJPUiBIQU5ETEVSJ1xuICAgIClcblxuICAgIFJvdXRlci5wdXNoKGAvYXV0aC9sb2dpbmAsIGAvbG9naW5gKVxuICB9XG5cbiAgaWYgKGUuc2hvd01pZCkge1xuICAgIHRvYXN0ci5lcnJvcignRXJyb3I6JywgZS5tZXNzYWdlKVxuICB9XG59XG5cbi8qKlxuICogaGFuZGxlU3RhdHVzQ2hlY2socmVzLCBkaXNwYXRjaClcbiAqIC0gUmVkdXggTWlkZGxld2FyZSBhcGlJbnRlcmNlcHRlciBzdGF0dXMgY2hlY2tcbiAqIC0gVXNlZCB0byB1cGxvYWQgZmlsZXMvcGhvdG9zXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGFwaSByZXNwb25zZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZGlzcGF0Y2hcbiAqIEByZXR1cm5zIEFjdGlvbiBkaXNwYXRjaCggbG9nVXNlck91dCApXG4gKiBAcmV0dXJucyB7RXJyb3J9XG4gKi9cbmV4cG9ydCBjb25zdCBoYW5kbGVTdGF0dXNDaGVjayA9IGFzeW5jIChyZXNwb25zZSwgZGlzcGF0Y2gsIGFjdGlvblR5cGUpID0+IHtcbiAgY29uc29sZS5sb2coJ2hhbmRsZSBTdGF0dXMgQ2hlY2snKVxuICBjb25zb2xlLmxvZyhyZXNwb25zZS5zdGF0dXMpXG5cbiAgY29uc3QgZXJyb3IgPSB7XG4gICAgc2hvd01pZDogZmFsc2UsIC8vIHNob3cgbWlkZGxld2FyZSBlcnJvciBpbnN0ZWFkIG9mIGhhbmRsaW5nIGVycm9yIGluIGEgY29tcG9uZW50XG4gICAgbWVzc2FnZTogJ1RoZXJlIHdhcyBhbiBlcnJvcidcbiAgfVxuXG4gIC8vIFNwZWNhaWwgbWVzc2FnZSBmb3IgbG9naW4gYWN0aW9uIGVycm9yXG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMSAmJiBhY3Rpb25UeXBlID09PSAnTE9HX1VTRVJfSU4nKSB7XG4gICAgZXJyb3IubWVzc2FnZSA9ICdJbmNvcnJlY3QgVXNlcm5hbWUgb3IgcGFzc3dvcmQnXG4gICAgdGhyb3cgZXJyb3JcbiAgfVxuXG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwMSkge1xuICAgIGVycm9yLnNob3dNaWQgPSB0cnVlXG4gICAgZXJyb3IubWVzc2FnZSA9ICdQbGVhc2UgbG9naW4gYWdhaW4nXG4gICAgYXdhaXQgZGlzcGF0Y2gobG9nVXNlck91dCgpKVxuICAgIHRocm93IGVycm9yXG4gIH1cblxuICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MjIpIHtcbiAgICBjb25zdCBuZXdFcnJvciA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxuXG4gICAgLypcbiAgICAqIFRoZSByZWdpc3RlcmZvcm0gY291bGQgcmV0dXJuIGFuIGFycmF5IG9mIGVycm9yc1xuICAgICogbm9ybWFsbHkgaXQgd2lsbCBqdXN0IHJldHVybiBhbiB7ZXJyb3I6ICdteSBlcnJvciBtc2cnfVxuICAgICovXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobmV3RXJyb3IuZXJyb3JzKSkge1xuICAgICAgdGhyb3cgbmV3RXJyb3IuZXJyb3JzXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ld0Vycm9yLmVycm9yXG4gICAgfVxuICB9XG5cbiAgaWYgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgZXJyb3IubWVzc2FnZSA9IHJlc3BvbnNlLnN0YXR1c1RleHRcbiAgICB0aHJvdyBlcnJvclxuICB9XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi91dGlscy9lcnJvckhhbmRsZXJzLmpzIl0sInNvdXJjZVJvb3QiOiIifQ==
            return { page: comp.default }
          })
        